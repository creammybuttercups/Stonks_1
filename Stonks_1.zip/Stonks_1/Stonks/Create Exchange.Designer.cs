﻿namespace Stonks
{
    partial class CreateExchange_Form_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateExchange_Button_1 = new System.Windows.Forms.Button();
            this.LastUpdated_TextBox_10 = new System.Windows.Forms.TextBox();
            this.CreatedDate_TextBox_10 = new System.Windows.Forms.TextBox();
            this.Currency_TextBox_10 = new System.Windows.Forms.TextBox();
            this.Name_TextBox_10 = new System.Windows.Forms.TextBox();
            this.LastUpdated_label_5 = new System.Windows.Forms.Label();
            this.CreatedDate_Label_5 = new System.Windows.Forms.Label();
            this.Currency_Label_5 = new System.Windows.Forms.Label();
            this.Name_Label_5 = new System.Windows.Forms.Label();
            this.CreateExchange_Label_2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CreateExchange_Button_1
            // 
            this.CreateExchange_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CreateExchange_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CreateExchange_Button_1.Location = new System.Drawing.Point(16, 475);
            this.CreateExchange_Button_1.Name = "CreateExchange_Button_1";
            this.CreateExchange_Button_1.Size = new System.Drawing.Size(91, 35);
            this.CreateExchange_Button_1.TabIndex = 87;
            this.CreateExchange_Button_1.Text = "Submit";
            this.CreateExchange_Button_1.UseVisualStyleBackColor = false;
            // 
            // LastUpdated_TextBox_10
            // 
            this.LastUpdated_TextBox_10.Location = new System.Drawing.Point(148, 361);
            this.LastUpdated_TextBox_10.Name = "LastUpdated_TextBox_10";
            this.LastUpdated_TextBox_10.Size = new System.Drawing.Size(100, 20);
            this.LastUpdated_TextBox_10.TabIndex = 86;
            // 
            // CreatedDate_TextBox_10
            // 
            this.CreatedDate_TextBox_10.Location = new System.Drawing.Point(148, 273);
            this.CreatedDate_TextBox_10.Name = "CreatedDate_TextBox_10";
            this.CreatedDate_TextBox_10.Size = new System.Drawing.Size(100, 20);
            this.CreatedDate_TextBox_10.TabIndex = 85;
            // 
            // Currency_TextBox_10
            // 
            this.Currency_TextBox_10.Location = new System.Drawing.Point(127, 183);
            this.Currency_TextBox_10.Name = "Currency_TextBox_10";
            this.Currency_TextBox_10.Size = new System.Drawing.Size(100, 20);
            this.Currency_TextBox_10.TabIndex = 84;
            // 
            // Name_TextBox_10
            // 
            this.Name_TextBox_10.Location = new System.Drawing.Point(127, 108);
            this.Name_TextBox_10.Name = "Name_TextBox_10";
            this.Name_TextBox_10.Size = new System.Drawing.Size(100, 20);
            this.Name_TextBox_10.TabIndex = 83;
            // 
            // LastUpdated_label_5
            // 
            this.LastUpdated_label_5.AutoSize = true;
            this.LastUpdated_label_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.LastUpdated_label_5.Location = new System.Drawing.Point(12, 361);
            this.LastUpdated_label_5.Name = "LastUpdated_label_5";
            this.LastUpdated_label_5.Size = new System.Drawing.Size(119, 24);
            this.LastUpdated_label_5.TabIndex = 82;
            this.LastUpdated_label_5.Text = "Last Updated";
            // 
            // CreatedDate_Label_5
            // 
            this.CreatedDate_Label_5.AutoSize = true;
            this.CreatedDate_Label_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CreatedDate_Label_5.Location = new System.Drawing.Point(12, 269);
            this.CreatedDate_Label_5.Name = "CreatedDate_Label_5";
            this.CreatedDate_Label_5.Size = new System.Drawing.Size(124, 24);
            this.CreatedDate_Label_5.TabIndex = 81;
            this.CreatedDate_Label_5.Text = " Created Date";
            // 
            // Currency_Label_5
            // 
            this.Currency_Label_5.AutoSize = true;
            this.Currency_Label_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Currency_Label_5.Location = new System.Drawing.Point(12, 190);
            this.Currency_Label_5.Name = "Currency_Label_5";
            this.Currency_Label_5.Size = new System.Drawing.Size(87, 24);
            this.Currency_Label_5.TabIndex = 80;
            this.Currency_Label_5.Text = "Currency";
            // 
            // Name_Label_5
            // 
            this.Name_Label_5.AutoSize = true;
            this.Name_Label_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Name_Label_5.Location = new System.Drawing.Point(12, 108);
            this.Name_Label_5.Name = "Name_Label_5";
            this.Name_Label_5.Size = new System.Drawing.Size(61, 24);
            this.Name_Label_5.TabIndex = 79;
            this.Name_Label_5.Text = "Name";
            // 
            // CreateExchange_Label_2
            // 
            this.CreateExchange_Label_2.AutoSize = true;
            this.CreateExchange_Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CreateExchange_Label_2.Location = new System.Drawing.Point(12, 9);
            this.CreateExchange_Label_2.Name = "CreateExchange_Label_2";
            this.CreateExchange_Label_2.Size = new System.Drawing.Size(157, 24);
            this.CreateExchange_Label_2.TabIndex = 78;
            this.CreateExchange_Label_2.Text = "Create Exchange";
            // 
            // CreateExchange_Form_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 876);
            this.Controls.Add(this.CreateExchange_Button_1);
            this.Controls.Add(this.LastUpdated_TextBox_10);
            this.Controls.Add(this.CreatedDate_TextBox_10);
            this.Controls.Add(this.Currency_TextBox_10);
            this.Controls.Add(this.Name_TextBox_10);
            this.Controls.Add(this.LastUpdated_label_5);
            this.Controls.Add(this.CreatedDate_Label_5);
            this.Controls.Add(this.Currency_Label_5);
            this.Controls.Add(this.Name_Label_5);
            this.Controls.Add(this.CreateExchange_Label_2);
            this.Name = "CreateExchange_Form_1";
            this.Text = "Create Exchange";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CreateExchange_Button_1;
        private System.Windows.Forms.TextBox LastUpdated_TextBox_10;
        private System.Windows.Forms.TextBox CreatedDate_TextBox_10;
        private System.Windows.Forms.TextBox Currency_TextBox_10;
        private System.Windows.Forms.TextBox Name_TextBox_10;
        private System.Windows.Forms.Label LastUpdated_label_5;
        private System.Windows.Forms.Label CreatedDate_Label_5;
        private System.Windows.Forms.Label Currency_Label_5;
        private System.Windows.Forms.Label Name_Label_5;
        private System.Windows.Forms.Label CreateExchange_Label_2;
    }
}