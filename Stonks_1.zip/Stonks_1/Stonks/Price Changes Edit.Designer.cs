﻿namespace Stonks
{
    partial class PriceChangesEdit_Form_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LastUpdated_TextBox_1 = new System.Windows.Forms.TextBox();
            this.CreatedDate_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Currency_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Name_TextBox_1 = new System.Windows.Forms.TextBox();
            this.LastUpdated_label_3 = new System.Windows.Forms.Label();
            this.CreatedDate_Label_3 = new System.Windows.Forms.Label();
            this.Currency_Label_3 = new System.Windows.Forms.Label();
            this.Name_Label_6 = new System.Windows.Forms.Label();
            this.Volume_TextBox_1 = new System.Windows.Forms.TextBox();
            this.PriceDate_TextBox_1 = new System.Windows.Forms.TextBox();
            this.AdjClosePrice_TextBox_1 = new System.Windows.Forms.TextBox();
            this.ClosePrice_TextBox_1 = new System.Windows.Forms.TextBox();
            this.LowPrice_TextBox_1 = new System.Windows.Forms.TextBox();
            this.HighPrice_TextBox_1 = new System.Windows.Forms.TextBox();
            this.OpenPrice_TextBox_1 = new System.Windows.Forms.TextBox();
            this.PriceDate_Label_3 = new System.Windows.Forms.Label();
            this.Volume_Label_3 = new System.Windows.Forms.Label();
            this.AdjClosePrice_Label_3 = new System.Windows.Forms.Label();
            this.ClosePrice_Label_3 = new System.Windows.Forms.Label();
            this.LowPrice_Label_3 = new System.Windows.Forms.Label();
            this.HighPrice_Label_3 = new System.Windows.Forms.Label();
            this.OpenPrice_label_3 = new System.Windows.Forms.Label();
            this.PriceChangesEdit_Label_1 = new System.Windows.Forms.Label();
            this.PriceChangesEdit_Button_1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LastUpdated_TextBox_1
            // 
            this.LastUpdated_TextBox_1.Location = new System.Drawing.Point(148, 357);
            this.LastUpdated_TextBox_1.Name = "LastUpdated_TextBox_1";
            this.LastUpdated_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.LastUpdated_TextBox_1.TabIndex = 104;
            // 
            // CreatedDate_TextBox_1
            // 
            this.CreatedDate_TextBox_1.Location = new System.Drawing.Point(148, 283);
            this.CreatedDate_TextBox_1.Name = "CreatedDate_TextBox_1";
            this.CreatedDate_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.CreatedDate_TextBox_1.TabIndex = 103;
            // 
            // Currency_TextBox_1
            // 
            this.Currency_TextBox_1.Location = new System.Drawing.Point(127, 193);
            this.Currency_TextBox_1.Name = "Currency_TextBox_1";
            this.Currency_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Currency_TextBox_1.TabIndex = 102;
            // 
            // Name_TextBox_1
            // 
            this.Name_TextBox_1.Location = new System.Drawing.Point(127, 118);
            this.Name_TextBox_1.Name = "Name_TextBox_1";
            this.Name_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Name_TextBox_1.TabIndex = 101;
            // 
            // LastUpdated_label_3
            // 
            this.LastUpdated_label_3.AutoSize = true;
            this.LastUpdated_label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.LastUpdated_label_3.Location = new System.Drawing.Point(12, 353);
            this.LastUpdated_label_3.Name = "LastUpdated_label_3";
            this.LastUpdated_label_3.Size = new System.Drawing.Size(119, 24);
            this.LastUpdated_label_3.TabIndex = 100;
            this.LastUpdated_label_3.Text = "Last Updated";
            // 
            // CreatedDate_Label_3
            // 
            this.CreatedDate_Label_3.AutoSize = true;
            this.CreatedDate_Label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CreatedDate_Label_3.Location = new System.Drawing.Point(12, 279);
            this.CreatedDate_Label_3.Name = "CreatedDate_Label_3";
            this.CreatedDate_Label_3.Size = new System.Drawing.Size(124, 24);
            this.CreatedDate_Label_3.TabIndex = 99;
            this.CreatedDate_Label_3.Text = " Created Date";
            // 
            // Currency_Label_3
            // 
            this.Currency_Label_3.AutoSize = true;
            this.Currency_Label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Currency_Label_3.Location = new System.Drawing.Point(12, 200);
            this.Currency_Label_3.Name = "Currency_Label_3";
            this.Currency_Label_3.Size = new System.Drawing.Size(87, 24);
            this.Currency_Label_3.TabIndex = 98;
            this.Currency_Label_3.Text = "Currency";
            // 
            // Name_Label_6
            // 
            this.Name_Label_6.AutoSize = true;
            this.Name_Label_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Name_Label_6.Location = new System.Drawing.Point(12, 118);
            this.Name_Label_6.Name = "Name_Label_6";
            this.Name_Label_6.Size = new System.Drawing.Size(61, 24);
            this.Name_Label_6.TabIndex = 97;
            this.Name_Label_6.Text = "Name";
            // 
            // Volume_TextBox_1
            // 
            this.Volume_TextBox_1.Location = new System.Drawing.Point(462, 417);
            this.Volume_TextBox_1.Name = "Volume_TextBox_1";
            this.Volume_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Volume_TextBox_1.TabIndex = 96;
            // 
            // PriceDate_TextBox_1
            // 
            this.PriceDate_TextBox_1.Location = new System.Drawing.Point(781, 116);
            this.PriceDate_TextBox_1.Name = "PriceDate_TextBox_1";
            this.PriceDate_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.PriceDate_TextBox_1.TabIndex = 95;
            // 
            // AdjClosePrice_TextBox_1
            // 
            this.AdjClosePrice_TextBox_1.Location = new System.Drawing.Point(520, 356);
            this.AdjClosePrice_TextBox_1.Name = "AdjClosePrice_TextBox_1";
            this.AdjClosePrice_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.AdjClosePrice_TextBox_1.TabIndex = 94;
            // 
            // ClosePrice_TextBox_1
            // 
            this.ClosePrice_TextBox_1.Location = new System.Drawing.Point(464, 279);
            this.ClosePrice_TextBox_1.Name = "ClosePrice_TextBox_1";
            this.ClosePrice_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.ClosePrice_TextBox_1.TabIndex = 93;
            // 
            // LowPrice_TextBox_1
            // 
            this.LowPrice_TextBox_1.Location = new System.Drawing.Point(462, 193);
            this.LowPrice_TextBox_1.Name = "LowPrice_TextBox_1";
            this.LowPrice_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.LowPrice_TextBox_1.TabIndex = 92;
            // 
            // HighPrice_TextBox_1
            // 
            this.HighPrice_TextBox_1.Location = new System.Drawing.Point(488, 117);
            this.HighPrice_TextBox_1.Name = "HighPrice_TextBox_1";
            this.HighPrice_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.HighPrice_TextBox_1.TabIndex = 91;
            // 
            // OpenPrice_TextBox_1
            // 
            this.OpenPrice_TextBox_1.Location = new System.Drawing.Point(143, 422);
            this.OpenPrice_TextBox_1.Name = "OpenPrice_TextBox_1";
            this.OpenPrice_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.OpenPrice_TextBox_1.TabIndex = 90;
            // 
            // PriceDate_Label_3
            // 
            this.PriceDate_Label_3.AutoSize = true;
            this.PriceDate_Label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.PriceDate_Label_3.Location = new System.Drawing.Point(675, 112);
            this.PriceDate_Label_3.Name = "PriceDate_Label_3";
            this.PriceDate_Label_3.Size = new System.Drawing.Size(96, 24);
            this.PriceDate_Label_3.TabIndex = 89;
            this.PriceDate_Label_3.Text = "Price Date";
            // 
            // Volume_Label_3
            // 
            this.Volume_Label_3.AutoSize = true;
            this.Volume_Label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Volume_Label_3.Location = new System.Drawing.Point(355, 417);
            this.Volume_Label_3.Name = "Volume_Label_3";
            this.Volume_Label_3.Size = new System.Drawing.Size(76, 24);
            this.Volume_Label_3.TabIndex = 88;
            this.Volume_Label_3.Text = "Volume";
            // 
            // AdjClosePrice_Label_3
            // 
            this.AdjClosePrice_Label_3.AutoSize = true;
            this.AdjClosePrice_Label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.AdjClosePrice_Label_3.Location = new System.Drawing.Point(355, 352);
            this.AdjClosePrice_Label_3.Name = "AdjClosePrice_Label_3";
            this.AdjClosePrice_Label_3.Size = new System.Drawing.Size(139, 24);
            this.AdjClosePrice_Label_3.TabIndex = 87;
            this.AdjClosePrice_Label_3.Text = "Adj Close Price";
            // 
            // ClosePrice_Label_3
            // 
            this.ClosePrice_Label_3.AutoSize = true;
            this.ClosePrice_Label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.ClosePrice_Label_3.Location = new System.Drawing.Point(355, 278);
            this.ClosePrice_Label_3.Name = "ClosePrice_Label_3";
            this.ClosePrice_Label_3.Size = new System.Drawing.Size(106, 24);
            this.ClosePrice_Label_3.TabIndex = 86;
            this.ClosePrice_Label_3.Text = "Close Price";
            // 
            // LowPrice_Label_3
            // 
            this.LowPrice_Label_3.AutoSize = true;
            this.LowPrice_Label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.LowPrice_Label_3.Location = new System.Drawing.Point(355, 189);
            this.LowPrice_Label_3.Name = "LowPrice_Label_3";
            this.LowPrice_Label_3.Size = new System.Drawing.Size(93, 24);
            this.LowPrice_Label_3.TabIndex = 85;
            this.LowPrice_Label_3.Text = "Low Price";
            // 
            // HighPrice_Label_3
            // 
            this.HighPrice_Label_3.AutoSize = true;
            this.HighPrice_Label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.HighPrice_Label_3.Location = new System.Drawing.Point(355, 113);
            this.HighPrice_Label_3.Name = "HighPrice_Label_3";
            this.HighPrice_Label_3.Size = new System.Drawing.Size(98, 24);
            this.HighPrice_Label_3.TabIndex = 84;
            this.HighPrice_Label_3.Text = "High Price";
            // 
            // OpenPrice_label_3
            // 
            this.OpenPrice_label_3.AutoSize = true;
            this.OpenPrice_label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.OpenPrice_label_3.Location = new System.Drawing.Point(6, 422);
            this.OpenPrice_label_3.Name = "OpenPrice_label_3";
            this.OpenPrice_label_3.Size = new System.Drawing.Size(106, 24);
            this.OpenPrice_label_3.TabIndex = 83;
            this.OpenPrice_label_3.Text = "Open Price";
            // 
            // PriceChangesEdit_Label_1
            // 
            this.PriceChangesEdit_Label_1.AutoSize = true;
            this.PriceChangesEdit_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.PriceChangesEdit_Label_1.Location = new System.Drawing.Point(16, 25);
            this.PriceChangesEdit_Label_1.Name = "PriceChangesEdit_Label_1";
            this.PriceChangesEdit_Label_1.Size = new System.Drawing.Size(199, 26);
            this.PriceChangesEdit_Label_1.TabIndex = 105;
            this.PriceChangesEdit_Label_1.Text = "Price Changes Edit";
            // 
            // PriceChangesEdit_Button_1
            // 
            this.PriceChangesEdit_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PriceChangesEdit_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.PriceChangesEdit_Button_1.Location = new System.Drawing.Point(781, 239);
            this.PriceChangesEdit_Button_1.Name = "PriceChangesEdit_Button_1";
            this.PriceChangesEdit_Button_1.Size = new System.Drawing.Size(91, 35);
            this.PriceChangesEdit_Button_1.TabIndex = 106;
            this.PriceChangesEdit_Button_1.Text = "Submit";
            this.PriceChangesEdit_Button_1.UseVisualStyleBackColor = false;
            // 
            // PriceChangesEdit_Form_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 876);
            this.Controls.Add(this.PriceChangesEdit_Button_1);
            this.Controls.Add(this.PriceChangesEdit_Label_1);
            this.Controls.Add(this.LastUpdated_TextBox_1);
            this.Controls.Add(this.CreatedDate_TextBox_1);
            this.Controls.Add(this.Currency_TextBox_1);
            this.Controls.Add(this.Name_TextBox_1);
            this.Controls.Add(this.LastUpdated_label_3);
            this.Controls.Add(this.CreatedDate_Label_3);
            this.Controls.Add(this.Currency_Label_3);
            this.Controls.Add(this.Name_Label_6);
            this.Controls.Add(this.Volume_TextBox_1);
            this.Controls.Add(this.PriceDate_TextBox_1);
            this.Controls.Add(this.AdjClosePrice_TextBox_1);
            this.Controls.Add(this.ClosePrice_TextBox_1);
            this.Controls.Add(this.LowPrice_TextBox_1);
            this.Controls.Add(this.HighPrice_TextBox_1);
            this.Controls.Add(this.OpenPrice_TextBox_1);
            this.Controls.Add(this.PriceDate_Label_3);
            this.Controls.Add(this.Volume_Label_3);
            this.Controls.Add(this.AdjClosePrice_Label_3);
            this.Controls.Add(this.ClosePrice_Label_3);
            this.Controls.Add(this.LowPrice_Label_3);
            this.Controls.Add(this.HighPrice_Label_3);
            this.Controls.Add(this.OpenPrice_label_3);
            this.Name = "PriceChangesEdit_Form_1";
            this.Text = "Price Changes Edit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox LastUpdated_TextBox_1;
        private System.Windows.Forms.TextBox CreatedDate_TextBox_1;
        private System.Windows.Forms.TextBox Currency_TextBox_1;
        private System.Windows.Forms.TextBox Name_TextBox_1;
        private System.Windows.Forms.Label LastUpdated_label_3;
        private System.Windows.Forms.Label CreatedDate_Label_3;
        private System.Windows.Forms.Label Currency_Label_3;
        private System.Windows.Forms.Label Name_Label_6;
        private System.Windows.Forms.TextBox Volume_TextBox_1;
        private System.Windows.Forms.TextBox PriceDate_TextBox_1;
        private System.Windows.Forms.TextBox AdjClosePrice_TextBox_1;
        private System.Windows.Forms.TextBox ClosePrice_TextBox_1;
        private System.Windows.Forms.TextBox LowPrice_TextBox_1;
        private System.Windows.Forms.TextBox HighPrice_TextBox_1;
        private System.Windows.Forms.TextBox OpenPrice_TextBox_1;
        private System.Windows.Forms.Label PriceDate_Label_3;
        private System.Windows.Forms.Label Volume_Label_3;
        private System.Windows.Forms.Label AdjClosePrice_Label_3;
        private System.Windows.Forms.Label ClosePrice_Label_3;
        private System.Windows.Forms.Label LowPrice_Label_3;
        private System.Windows.Forms.Label HighPrice_Label_3;
        private System.Windows.Forms.Label OpenPrice_label_3;
        private System.Windows.Forms.Label PriceChangesEdit_Label_1;
        private System.Windows.Forms.Button PriceChangesEdit_Button_1;
    }
}