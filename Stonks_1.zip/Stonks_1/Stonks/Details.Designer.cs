﻿namespace Stonks
{
    partial class Details_form_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CompanyDetails_Label_1 = new System.Windows.Forms.Label();
            this.PriceExchangeDetails_Label_1 = new System.Windows.Forms.Label();
            this.PriceExchangeDetails_Create_Button_1 = new System.Windows.Forms.Button();
            this.PriceExchangeDetails_Edit_Button_1 = new System.Windows.Forms.Button();
            this.PriceExchangeDetails_Delete_Button_1 = new System.Windows.Forms.Button();
            this.ZipCode_TextBox_2 = new System.Windows.Forms.TextBox();
            this.Address_TextBox_2 = new System.Windows.Forms.TextBox();
            this.Phone_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Ceo_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Description_TextBox_2 = new System.Windows.Forms.TextBox();
            this.WebsiteURL_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Industry_TextBox_2 = new System.Windows.Forms.TextBox();
            this.Sector_TextBox_2 = new System.Windows.Forms.TextBox();
            this.Name_TextBox_9 = new System.Windows.Forms.TextBox();
            this.Symbol_TextBox_2 = new System.Windows.Forms.TextBox();
            this.ZipCode_Label_4 = new System.Windows.Forms.Label();
            this.City_Label_4 = new System.Windows.Forms.Label();
            this.Address_Label_4 = new System.Windows.Forms.Label();
            this.Phone_Label_4 = new System.Windows.Forms.Label();
            this.Country_Label_4 = new System.Windows.Forms.Label();
            this.CEO_Label_4 = new System.Windows.Forms.Label();
            this.Desc_Label_4 = new System.Windows.Forms.Label();
            this.WebsiteURL_Label_4 = new System.Windows.Forms.Label();
            this.Industry_Label_4 = new System.Windows.Forms.Label();
            this.Sector_Label_4 = new System.Windows.Forms.Label();
            this.Name_Label_4 = new System.Windows.Forms.Label();
            this.Symbol_Label_4 = new System.Windows.Forms.Label();
            this.City_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Country_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Volume_TextBox_8 = new System.Windows.Forms.TextBox();
            this.PriceDate_TextBox_8 = new System.Windows.Forms.TextBox();
            this.AdjClosePrice_TextBox_8 = new System.Windows.Forms.TextBox();
            this.ClosePrice_TextBox_8 = new System.Windows.Forms.TextBox();
            this.LowPrice_TextBox_8 = new System.Windows.Forms.TextBox();
            this.HighPrice_TextBox_8 = new System.Windows.Forms.TextBox();
            this.OpenPirce_TextBox_8 = new System.Windows.Forms.TextBox();
            this.PriceDate_Label_2 = new System.Windows.Forms.Label();
            this.Volume_Label_1 = new System.Windows.Forms.Label();
            this.AdjClosePrice_Label_1 = new System.Windows.Forms.Label();
            this.ClosePrice_Label_1 = new System.Windows.Forms.Label();
            this.LowPrice_Label_1 = new System.Windows.Forms.Label();
            this.HighPrice_Label_1 = new System.Windows.Forms.Label();
            this.OpenPrice_label_2 = new System.Windows.Forms.Label();
            this.LastUpdated_TextBox_8 = new System.Windows.Forms.TextBox();
            this.CreatedDate_TextBox_8 = new System.Windows.Forms.TextBox();
            this.Currency_TextBox_8 = new System.Windows.Forms.TextBox();
            this.Name_TextBox_8 = new System.Windows.Forms.TextBox();
            this.LastUpdated_label_1 = new System.Windows.Forms.Label();
            this.CreatedDate_Label_2 = new System.Windows.Forms.Label();
            this.Currency_Label_2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CompanyDetails_Label_1
            // 
            this.CompanyDetails_Label_1.AutoSize = true;
            this.CompanyDetails_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.CompanyDetails_Label_1.Location = new System.Drawing.Point(13, 13);
            this.CompanyDetails_Label_1.Name = "CompanyDetails_Label_1";
            this.CompanyDetails_Label_1.Size = new System.Drawing.Size(179, 26);
            this.CompanyDetails_Label_1.TabIndex = 0;
            this.CompanyDetails_Label_1.Text = "Company Details";
            // 
            // PriceExchangeDetails_Label_1
            // 
            this.PriceExchangeDetails_Label_1.AutoSize = true;
            this.PriceExchangeDetails_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.PriceExchangeDetails_Label_1.Location = new System.Drawing.Point(13, 464);
            this.PriceExchangeDetails_Label_1.Name = "PriceExchangeDetails_Label_1";
            this.PriceExchangeDetails_Label_1.Size = new System.Drawing.Size(235, 26);
            this.PriceExchangeDetails_Label_1.TabIndex = 1;
            this.PriceExchangeDetails_Label_1.Text = "Price exchange Details";
            // 
            // PriceExchangeDetails_Create_Button_1
            // 
            this.PriceExchangeDetails_Create_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PriceExchangeDetails_Create_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.PriceExchangeDetails_Create_Button_1.Location = new System.Drawing.Point(786, 466);
            this.PriceExchangeDetails_Create_Button_1.Name = "PriceExchangeDetails_Create_Button_1";
            this.PriceExchangeDetails_Create_Button_1.Size = new System.Drawing.Size(91, 34);
            this.PriceExchangeDetails_Create_Button_1.TabIndex = 2;
            this.PriceExchangeDetails_Create_Button_1.Text = "Create";
            this.PriceExchangeDetails_Create_Button_1.UseVisualStyleBackColor = false;
            // 
            // PriceExchangeDetails_Edit_Button_1
            // 
            this.PriceExchangeDetails_Edit_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PriceExchangeDetails_Edit_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.PriceExchangeDetails_Edit_Button_1.Location = new System.Drawing.Point(941, 464);
            this.PriceExchangeDetails_Edit_Button_1.Name = "PriceExchangeDetails_Edit_Button_1";
            this.PriceExchangeDetails_Edit_Button_1.Size = new System.Drawing.Size(91, 34);
            this.PriceExchangeDetails_Edit_Button_1.TabIndex = 3;
            this.PriceExchangeDetails_Edit_Button_1.Text = "Edit";
            this.PriceExchangeDetails_Edit_Button_1.UseVisualStyleBackColor = false;
            // 
            // PriceExchangeDetails_Delete_Button_1
            // 
            this.PriceExchangeDetails_Delete_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PriceExchangeDetails_Delete_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.PriceExchangeDetails_Delete_Button_1.Location = new System.Drawing.Point(1081, 462);
            this.PriceExchangeDetails_Delete_Button_1.Name = "PriceExchangeDetails_Delete_Button_1";
            this.PriceExchangeDetails_Delete_Button_1.Size = new System.Drawing.Size(91, 34);
            this.PriceExchangeDetails_Delete_Button_1.TabIndex = 4;
            this.PriceExchangeDetails_Delete_Button_1.Text = "Delete";
            this.PriceExchangeDetails_Delete_Button_1.UseVisualStyleBackColor = false;
            // 
            // ZipCode_TextBox_2
            // 
            this.ZipCode_TextBox_2.Location = new System.Drawing.Point(786, 51);
            this.ZipCode_TextBox_2.Name = "ZipCode_TextBox_2";
            this.ZipCode_TextBox_2.ReadOnly = true;
            this.ZipCode_TextBox_2.Size = new System.Drawing.Size(100, 20);
            this.ZipCode_TextBox_2.TabIndex = 46;
            // 
            // Address_TextBox_2
            // 
            this.Address_TextBox_2.Location = new System.Drawing.Point(467, 259);
            this.Address_TextBox_2.Name = "Address_TextBox_2";
            this.Address_TextBox_2.ReadOnly = true;
            this.Address_TextBox_2.Size = new System.Drawing.Size(100, 20);
            this.Address_TextBox_2.TabIndex = 45;
            // 
            // Phone_TextBox_1
            // 
            this.Phone_TextBox_1.Location = new System.Drawing.Point(467, 176);
            this.Phone_TextBox_1.Name = "Phone_TextBox_1";
            this.Phone_TextBox_1.ReadOnly = true;
            this.Phone_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Phone_TextBox_1.TabIndex = 44;
            // 
            // Ceo_TextBox_1
            // 
            this.Ceo_TextBox_1.Location = new System.Drawing.Point(467, 126);
            this.Ceo_TextBox_1.Name = "Ceo_TextBox_1";
            this.Ceo_TextBox_1.ReadOnly = true;
            this.Ceo_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Ceo_TextBox_1.TabIndex = 43;
            // 
            // Description_TextBox_2
            // 
            this.Description_TextBox_2.Location = new System.Drawing.Point(493, 51);
            this.Description_TextBox_2.Name = "Description_TextBox_2";
            this.Description_TextBox_2.ReadOnly = true;
            this.Description_TextBox_2.Size = new System.Drawing.Size(100, 20);
            this.Description_TextBox_2.TabIndex = 42;
            this.Description_TextBox_2.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // WebsiteURL_TextBox_1
            // 
            this.WebsiteURL_TextBox_1.Location = new System.Drawing.Point(129, 384);
            this.WebsiteURL_TextBox_1.Name = "WebsiteURL_TextBox_1";
            this.WebsiteURL_TextBox_1.ReadOnly = true;
            this.WebsiteURL_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.WebsiteURL_TextBox_1.TabIndex = 41;
            // 
            // Industry_TextBox_2
            // 
            this.Industry_TextBox_2.Location = new System.Drawing.Point(129, 297);
            this.Industry_TextBox_2.Name = "Industry_TextBox_2";
            this.Industry_TextBox_2.ReadOnly = true;
            this.Industry_TextBox_2.Size = new System.Drawing.Size(100, 20);
            this.Industry_TextBox_2.TabIndex = 40;
            // 
            // Sector_TextBox_2
            // 
            this.Sector_TextBox_2.Location = new System.Drawing.Point(129, 205);
            this.Sector_TextBox_2.Name = "Sector_TextBox_2";
            this.Sector_TextBox_2.ReadOnly = true;
            this.Sector_TextBox_2.Size = new System.Drawing.Size(100, 20);
            this.Sector_TextBox_2.TabIndex = 39;
            // 
            // Name_TextBox_9
            // 
            this.Name_TextBox_9.Location = new System.Drawing.Point(129, 126);
            this.Name_TextBox_9.Name = "Name_TextBox_9";
            this.Name_TextBox_9.ReadOnly = true;
            this.Name_TextBox_9.Size = new System.Drawing.Size(100, 20);
            this.Name_TextBox_9.TabIndex = 38;
            this.Name_TextBox_9.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // Symbol_TextBox_2
            // 
            this.Symbol_TextBox_2.Location = new System.Drawing.Point(129, 51);
            this.Symbol_TextBox_2.Name = "Symbol_TextBox_2";
            this.Symbol_TextBox_2.ReadOnly = true;
            this.Symbol_TextBox_2.Size = new System.Drawing.Size(100, 20);
            this.Symbol_TextBox_2.TabIndex = 37;
            this.Symbol_TextBox_2.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // ZipCode_Label_4
            // 
            this.ZipCode_Label_4.AutoSize = true;
            this.ZipCode_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.ZipCode_Label_4.Location = new System.Drawing.Point(680, 51);
            this.ZipCode_Label_4.Name = "ZipCode_Label_4";
            this.ZipCode_Label_4.Size = new System.Drawing.Size(83, 24);
            this.ZipCode_Label_4.TabIndex = 36;
            this.ZipCode_Label_4.Text = "ZipCode";
            // 
            // City_Label_4
            // 
            this.City_Label_4.AutoSize = true;
            this.City_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.City_Label_4.Location = new System.Drawing.Point(360, 345);
            this.City_Label_4.Name = "City_Label_4";
            this.City_Label_4.Size = new System.Drawing.Size(40, 24);
            this.City_Label_4.TabIndex = 35;
            this.City_Label_4.Text = "City";
            // 
            // Address_Label_4
            // 
            this.Address_Label_4.AutoSize = true;
            this.Address_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Address_Label_4.Location = new System.Drawing.Point(360, 266);
            this.Address_Label_4.Name = "Address_Label_4";
            this.Address_Label_4.Size = new System.Drawing.Size(80, 24);
            this.Address_Label_4.TabIndex = 34;
            this.Address_Label_4.Text = "Address";
            // 
            // Phone_Label_4
            // 
            this.Phone_Label_4.AutoSize = true;
            this.Phone_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Phone_Label_4.Location = new System.Drawing.Point(360, 184);
            this.Phone_Label_4.Name = "Phone_Label_4";
            this.Phone_Label_4.Size = new System.Drawing.Size(66, 24);
            this.Phone_Label_4.TabIndex = 33;
            this.Phone_Label_4.Text = "Phone";
            // 
            // Country_Label_4
            // 
            this.Country_Label_4.AutoSize = true;
            this.Country_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Country_Label_4.Location = new System.Drawing.Point(680, 121);
            this.Country_Label_4.Name = "Country_Label_4";
            this.Country_Label_4.Size = new System.Drawing.Size(75, 24);
            this.Country_Label_4.TabIndex = 32;
            this.Country_Label_4.Text = "Country";
            // 
            // CEO_Label_4
            // 
            this.CEO_Label_4.AutoSize = true;
            this.CEO_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CEO_Label_4.Location = new System.Drawing.Point(360, 122);
            this.CEO_Label_4.Name = "CEO_Label_4";
            this.CEO_Label_4.Size = new System.Drawing.Size(51, 24);
            this.CEO_Label_4.TabIndex = 31;
            this.CEO_Label_4.Text = "CEO";
            // 
            // Desc_Label_4
            // 
            this.Desc_Label_4.AutoSize = true;
            this.Desc_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Desc_Label_4.Location = new System.Drawing.Point(360, 51);
            this.Desc_Label_4.Name = "Desc_Label_4";
            this.Desc_Label_4.Size = new System.Drawing.Size(104, 24);
            this.Desc_Label_4.TabIndex = 30;
            this.Desc_Label_4.Text = "Description";
            // 
            // WebsiteURL_Label_4
            // 
            this.WebsiteURL_Label_4.AutoSize = true;
            this.WebsiteURL_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.WebsiteURL_Label_4.Location = new System.Drawing.Point(14, 391);
            this.WebsiteURL_Label_4.Name = "WebsiteURL_Label_4";
            this.WebsiteURL_Label_4.Size = new System.Drawing.Size(114, 24);
            this.WebsiteURL_Label_4.TabIndex = 29;
            this.WebsiteURL_Label_4.Text = "WebsiteURL";
            // 
            // Industry_Label_4
            // 
            this.Industry_Label_4.AutoSize = true;
            this.Industry_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Industry_Label_4.Location = new System.Drawing.Point(14, 304);
            this.Industry_Label_4.Name = "Industry_Label_4";
            this.Industry_Label_4.Size = new System.Drawing.Size(75, 24);
            this.Industry_Label_4.TabIndex = 28;
            this.Industry_Label_4.Text = "Indusrty";
            // 
            // Sector_Label_4
            // 
            this.Sector_Label_4.AutoSize = true;
            this.Sector_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Sector_Label_4.Location = new System.Drawing.Point(14, 212);
            this.Sector_Label_4.Name = "Sector_Label_4";
            this.Sector_Label_4.Size = new System.Drawing.Size(64, 24);
            this.Sector_Label_4.TabIndex = 27;
            this.Sector_Label_4.Text = "Sector";
            // 
            // Name_Label_4
            // 
            this.Name_Label_4.AutoSize = true;
            this.Name_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Name_Label_4.Location = new System.Drawing.Point(14, 133);
            this.Name_Label_4.Name = "Name_Label_4";
            this.Name_Label_4.Size = new System.Drawing.Size(61, 24);
            this.Name_Label_4.TabIndex = 26;
            this.Name_Label_4.Text = "Name";
            // 
            // Symbol_Label_4
            // 
            this.Symbol_Label_4.AutoSize = true;
            this.Symbol_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Symbol_Label_4.Location = new System.Drawing.Point(14, 51);
            this.Symbol_Label_4.Name = "Symbol_Label_4";
            this.Symbol_Label_4.Size = new System.Drawing.Size(73, 24);
            this.Symbol_Label_4.TabIndex = 25;
            this.Symbol_Label_4.Text = "Symbol";
            // 
            // City_TextBox_1
            // 
            this.City_TextBox_1.Location = new System.Drawing.Point(467, 345);
            this.City_TextBox_1.Name = "City_TextBox_1";
            this.City_TextBox_1.ReadOnly = true;
            this.City_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.City_TextBox_1.TabIndex = 49;
            // 
            // Country_TextBox_1
            // 
            this.Country_TextBox_1.Location = new System.Drawing.Point(786, 121);
            this.Country_TextBox_1.Name = "Country_TextBox_1";
            this.Country_TextBox_1.ReadOnly = true;
            this.Country_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Country_TextBox_1.TabIndex = 50;
            // 
            // Volume_TextBox_8
            // 
            this.Volume_TextBox_8.Location = new System.Drawing.Point(467, 838);
            this.Volume_TextBox_8.Name = "Volume_TextBox_8";
            this.Volume_TextBox_8.ReadOnly = true;
            this.Volume_TextBox_8.Size = new System.Drawing.Size(100, 20);
            this.Volume_TextBox_8.TabIndex = 73;
            // 
            // PriceDate_TextBox_8
            // 
            this.PriceDate_TextBox_8.Location = new System.Drawing.Point(786, 537);
            this.PriceDate_TextBox_8.Name = "PriceDate_TextBox_8";
            this.PriceDate_TextBox_8.ReadOnly = true;
            this.PriceDate_TextBox_8.Size = new System.Drawing.Size(100, 20);
            this.PriceDate_TextBox_8.TabIndex = 72;
            // 
            // AdjClosePrice_TextBox_8
            // 
            this.AdjClosePrice_TextBox_8.Location = new System.Drawing.Point(525, 777);
            this.AdjClosePrice_TextBox_8.Name = "AdjClosePrice_TextBox_8";
            this.AdjClosePrice_TextBox_8.ReadOnly = true;
            this.AdjClosePrice_TextBox_8.Size = new System.Drawing.Size(100, 20);
            this.AdjClosePrice_TextBox_8.TabIndex = 71;
            // 
            // ClosePrice_TextBox_8
            // 
            this.ClosePrice_TextBox_8.Location = new System.Drawing.Point(469, 700);
            this.ClosePrice_TextBox_8.Name = "ClosePrice_TextBox_8";
            this.ClosePrice_TextBox_8.ReadOnly = true;
            this.ClosePrice_TextBox_8.Size = new System.Drawing.Size(100, 20);
            this.ClosePrice_TextBox_8.TabIndex = 70;
            // 
            // LowPrice_TextBox_8
            // 
            this.LowPrice_TextBox_8.Location = new System.Drawing.Point(467, 614);
            this.LowPrice_TextBox_8.Name = "LowPrice_TextBox_8";
            this.LowPrice_TextBox_8.ReadOnly = true;
            this.LowPrice_TextBox_8.Size = new System.Drawing.Size(100, 20);
            this.LowPrice_TextBox_8.TabIndex = 69;
            // 
            // HighPrice_TextBox_8
            // 
            this.HighPrice_TextBox_8.Location = new System.Drawing.Point(493, 538);
            this.HighPrice_TextBox_8.Name = "HighPrice_TextBox_8";
            this.HighPrice_TextBox_8.ReadOnly = true;
            this.HighPrice_TextBox_8.Size = new System.Drawing.Size(100, 20);
            this.HighPrice_TextBox_8.TabIndex = 68;
            // 
            // OpenPirce_TextBox_8
            // 
            this.OpenPirce_TextBox_8.Location = new System.Drawing.Point(148, 843);
            this.OpenPirce_TextBox_8.Name = "OpenPirce_TextBox_8";
            this.OpenPirce_TextBox_8.ReadOnly = true;
            this.OpenPirce_TextBox_8.Size = new System.Drawing.Size(100, 20);
            this.OpenPirce_TextBox_8.TabIndex = 67;
            // 
            // PriceDate_Label_2
            // 
            this.PriceDate_Label_2.AutoSize = true;
            this.PriceDate_Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.PriceDate_Label_2.Location = new System.Drawing.Point(680, 533);
            this.PriceDate_Label_2.Name = "PriceDate_Label_2";
            this.PriceDate_Label_2.Size = new System.Drawing.Size(96, 24);
            this.PriceDate_Label_2.TabIndex = 62;
            this.PriceDate_Label_2.Text = "Price Date";
            // 
            // Volume_Label_1
            // 
            this.Volume_Label_1.AutoSize = true;
            this.Volume_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Volume_Label_1.Location = new System.Drawing.Point(360, 838);
            this.Volume_Label_1.Name = "Volume_Label_1";
            this.Volume_Label_1.Size = new System.Drawing.Size(76, 24);
            this.Volume_Label_1.TabIndex = 61;
            this.Volume_Label_1.Text = "Volume";
            // 
            // AdjClosePrice_Label_1
            // 
            this.AdjClosePrice_Label_1.AutoSize = true;
            this.AdjClosePrice_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.AdjClosePrice_Label_1.Location = new System.Drawing.Point(360, 773);
            this.AdjClosePrice_Label_1.Name = "AdjClosePrice_Label_1";
            this.AdjClosePrice_Label_1.Size = new System.Drawing.Size(139, 24);
            this.AdjClosePrice_Label_1.TabIndex = 60;
            this.AdjClosePrice_Label_1.Text = "Adj Close Price";
            // 
            // ClosePrice_Label_1
            // 
            this.ClosePrice_Label_1.AutoSize = true;
            this.ClosePrice_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.ClosePrice_Label_1.Location = new System.Drawing.Point(360, 699);
            this.ClosePrice_Label_1.Name = "ClosePrice_Label_1";
            this.ClosePrice_Label_1.Size = new System.Drawing.Size(106, 24);
            this.ClosePrice_Label_1.TabIndex = 59;
            this.ClosePrice_Label_1.Text = "Close Price";
            // 
            // LowPrice_Label_1
            // 
            this.LowPrice_Label_1.AutoSize = true;
            this.LowPrice_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.LowPrice_Label_1.Location = new System.Drawing.Point(360, 610);
            this.LowPrice_Label_1.Name = "LowPrice_Label_1";
            this.LowPrice_Label_1.Size = new System.Drawing.Size(93, 24);
            this.LowPrice_Label_1.TabIndex = 57;
            this.LowPrice_Label_1.Text = "Low Price";
            // 
            // HighPrice_Label_1
            // 
            this.HighPrice_Label_1.AutoSize = true;
            this.HighPrice_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.HighPrice_Label_1.Location = new System.Drawing.Point(360, 534);
            this.HighPrice_Label_1.Name = "HighPrice_Label_1";
            this.HighPrice_Label_1.Size = new System.Drawing.Size(98, 24);
            this.HighPrice_Label_1.TabIndex = 56;
            this.HighPrice_Label_1.Text = "High Price";
            // 
            // OpenPrice_label_2
            // 
            this.OpenPrice_label_2.AutoSize = true;
            this.OpenPrice_label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.OpenPrice_label_2.Location = new System.Drawing.Point(11, 843);
            this.OpenPrice_label_2.Name = "OpenPrice_label_2";
            this.OpenPrice_label_2.Size = new System.Drawing.Size(106, 24);
            this.OpenPrice_label_2.TabIndex = 55;
            this.OpenPrice_label_2.Text = "Open Price";
            // 
            // LastUpdated_TextBox_8
            // 
            this.LastUpdated_TextBox_8.Location = new System.Drawing.Point(153, 778);
            this.LastUpdated_TextBox_8.Name = "LastUpdated_TextBox_8";
            this.LastUpdated_TextBox_8.Size = new System.Drawing.Size(100, 20);
            this.LastUpdated_TextBox_8.TabIndex = 82;
            // 
            // CreatedDate_TextBox_8
            // 
            this.CreatedDate_TextBox_8.Location = new System.Drawing.Point(153, 704);
            this.CreatedDate_TextBox_8.Name = "CreatedDate_TextBox_8";
            this.CreatedDate_TextBox_8.Size = new System.Drawing.Size(100, 20);
            this.CreatedDate_TextBox_8.TabIndex = 81;
            // 
            // Currency_TextBox_8
            // 
            this.Currency_TextBox_8.Location = new System.Drawing.Point(132, 614);
            this.Currency_TextBox_8.Name = "Currency_TextBox_8";
            this.Currency_TextBox_8.Size = new System.Drawing.Size(100, 20);
            this.Currency_TextBox_8.TabIndex = 80;
            // 
            // Name_TextBox_8
            // 
            this.Name_TextBox_8.Location = new System.Drawing.Point(132, 539);
            this.Name_TextBox_8.Name = "Name_TextBox_8";
            this.Name_TextBox_8.Size = new System.Drawing.Size(100, 20);
            this.Name_TextBox_8.TabIndex = 79;
            // 
            // LastUpdated_label_1
            // 
            this.LastUpdated_label_1.AutoSize = true;
            this.LastUpdated_label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.LastUpdated_label_1.Location = new System.Drawing.Point(17, 774);
            this.LastUpdated_label_1.Name = "LastUpdated_label_1";
            this.LastUpdated_label_1.Size = new System.Drawing.Size(119, 24);
            this.LastUpdated_label_1.TabIndex = 78;
            this.LastUpdated_label_1.Text = "Last Updated";
            // 
            // CreatedDate_Label_2
            // 
            this.CreatedDate_Label_2.AutoSize = true;
            this.CreatedDate_Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CreatedDate_Label_2.Location = new System.Drawing.Point(17, 700);
            this.CreatedDate_Label_2.Name = "CreatedDate_Label_2";
            this.CreatedDate_Label_2.Size = new System.Drawing.Size(124, 24);
            this.CreatedDate_Label_2.TabIndex = 77;
            this.CreatedDate_Label_2.Text = " Created Date";
            // 
            // Currency_Label_2
            // 
            this.Currency_Label_2.AutoSize = true;
            this.Currency_Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Currency_Label_2.Location = new System.Drawing.Point(17, 621);
            this.Currency_Label_2.Name = "Currency_Label_2";
            this.Currency_Label_2.Size = new System.Drawing.Size(87, 24);
            this.Currency_Label_2.TabIndex = 76;
            this.Currency_Label_2.Text = "Currency";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label9.Location = new System.Drawing.Point(17, 539);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 24);
            this.label9.TabIndex = 75;
            this.label9.Text = "Name";
            // 
            // Details_form_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 876);
            this.Controls.Add(this.LastUpdated_TextBox_8);
            this.Controls.Add(this.CreatedDate_TextBox_8);
            this.Controls.Add(this.Currency_TextBox_8);
            this.Controls.Add(this.Name_TextBox_8);
            this.Controls.Add(this.LastUpdated_label_1);
            this.Controls.Add(this.CreatedDate_Label_2);
            this.Controls.Add(this.Currency_Label_2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Volume_TextBox_8);
            this.Controls.Add(this.PriceDate_TextBox_8);
            this.Controls.Add(this.AdjClosePrice_TextBox_8);
            this.Controls.Add(this.ClosePrice_TextBox_8);
            this.Controls.Add(this.LowPrice_TextBox_8);
            this.Controls.Add(this.HighPrice_TextBox_8);
            this.Controls.Add(this.OpenPirce_TextBox_8);
            this.Controls.Add(this.PriceDate_Label_2);
            this.Controls.Add(this.Volume_Label_1);
            this.Controls.Add(this.AdjClosePrice_Label_1);
            this.Controls.Add(this.ClosePrice_Label_1);
            this.Controls.Add(this.LowPrice_Label_1);
            this.Controls.Add(this.HighPrice_Label_1);
            this.Controls.Add(this.OpenPrice_label_2);
            this.Controls.Add(this.Country_TextBox_1);
            this.Controls.Add(this.City_TextBox_1);
            this.Controls.Add(this.ZipCode_TextBox_2);
            this.Controls.Add(this.Address_TextBox_2);
            this.Controls.Add(this.Phone_TextBox_1);
            this.Controls.Add(this.Ceo_TextBox_1);
            this.Controls.Add(this.Description_TextBox_2);
            this.Controls.Add(this.WebsiteURL_TextBox_1);
            this.Controls.Add(this.Industry_TextBox_2);
            this.Controls.Add(this.Sector_TextBox_2);
            this.Controls.Add(this.Name_TextBox_9);
            this.Controls.Add(this.Symbol_TextBox_2);
            this.Controls.Add(this.ZipCode_Label_4);
            this.Controls.Add(this.City_Label_4);
            this.Controls.Add(this.Address_Label_4);
            this.Controls.Add(this.Phone_Label_4);
            this.Controls.Add(this.Country_Label_4);
            this.Controls.Add(this.CEO_Label_4);
            this.Controls.Add(this.Desc_Label_4);
            this.Controls.Add(this.WebsiteURL_Label_4);
            this.Controls.Add(this.Industry_Label_4);
            this.Controls.Add(this.Sector_Label_4);
            this.Controls.Add(this.Name_Label_4);
            this.Controls.Add(this.Symbol_Label_4);
            this.Controls.Add(this.PriceExchangeDetails_Delete_Button_1);
            this.Controls.Add(this.PriceExchangeDetails_Edit_Button_1);
            this.Controls.Add(this.PriceExchangeDetails_Create_Button_1);
            this.Controls.Add(this.PriceExchangeDetails_Label_1);
            this.Controls.Add(this.CompanyDetails_Label_1);
            this.Name = "Details_form_1";
            this.Text = "Details";
            this.Load += new System.EventHandler(this.Details_form_1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label CompanyDetails_Label_1;
        private System.Windows.Forms.Label PriceExchangeDetails_Label_1;
        private System.Windows.Forms.Button PriceExchangeDetails_Create_Button_1;
        private System.Windows.Forms.Button PriceExchangeDetails_Edit_Button_1;
        private System.Windows.Forms.Button PriceExchangeDetails_Delete_Button_1;
        private System.Windows.Forms.TextBox ZipCode_TextBox_2;
        private System.Windows.Forms.TextBox Address_TextBox_2;
        private System.Windows.Forms.TextBox Phone_TextBox_1;
        private System.Windows.Forms.TextBox Ceo_TextBox_1;
        private System.Windows.Forms.TextBox Description_TextBox_2;
        private System.Windows.Forms.TextBox WebsiteURL_TextBox_1;
        private System.Windows.Forms.TextBox Industry_TextBox_2;
        private System.Windows.Forms.TextBox Sector_TextBox_2;
        private System.Windows.Forms.TextBox Name_TextBox_9;
        private System.Windows.Forms.TextBox Symbol_TextBox_2;
        private System.Windows.Forms.Label ZipCode_Label_4;
        private System.Windows.Forms.Label City_Label_4;
        private System.Windows.Forms.Label Address_Label_4;
        private System.Windows.Forms.Label Phone_Label_4;
        private System.Windows.Forms.Label Country_Label_4;
        private System.Windows.Forms.Label CEO_Label_4;
        private System.Windows.Forms.Label Desc_Label_4;
        private System.Windows.Forms.Label WebsiteURL_Label_4;
        private System.Windows.Forms.Label Industry_Label_4;
        private System.Windows.Forms.Label Sector_Label_4;
        private System.Windows.Forms.Label Name_Label_4;
        private System.Windows.Forms.Label Symbol_Label_4;
        private System.Windows.Forms.TextBox City_TextBox_1;
        private System.Windows.Forms.TextBox Country_TextBox_1;
        private System.Windows.Forms.TextBox Volume_TextBox_8;
        private System.Windows.Forms.TextBox PriceDate_TextBox_8;
        private System.Windows.Forms.TextBox AdjClosePrice_TextBox_8;
        private System.Windows.Forms.TextBox ClosePrice_TextBox_8;
        private System.Windows.Forms.TextBox LowPrice_TextBox_8;
        private System.Windows.Forms.TextBox HighPrice_TextBox_8;
        private System.Windows.Forms.TextBox OpenPirce_TextBox_8;
        private System.Windows.Forms.Label PriceDate_Label_2;
        private System.Windows.Forms.Label Volume_Label_1;
        private System.Windows.Forms.Label AdjClosePrice_Label_1;
        private System.Windows.Forms.Label ClosePrice_Label_1;
        private System.Windows.Forms.Label LowPrice_Label_1;
        private System.Windows.Forms.Label HighPrice_Label_1;
        private System.Windows.Forms.Label OpenPrice_label_2;
        private System.Windows.Forms.TextBox LastUpdated_TextBox_8;
        private System.Windows.Forms.TextBox CreatedDate_TextBox_8;
        private System.Windows.Forms.TextBox Currency_TextBox_8;
        private System.Windows.Forms.TextBox Name_TextBox_8;
        private System.Windows.Forms.Label LastUpdated_label_1;
        private System.Windows.Forms.Label CreatedDate_Label_2;
        private System.Windows.Forms.Label Currency_Label_2;
        private System.Windows.Forms.Label label9;
    }
}