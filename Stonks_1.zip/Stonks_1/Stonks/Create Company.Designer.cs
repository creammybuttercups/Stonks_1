﻿namespace Stonks
{
    partial class CreateCompany_Form_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateCompany_Label_1 = new System.Windows.Forms.Label();
            this.Symbol_Label_2 = new System.Windows.Forms.Label();
            this.Name_Label_1 = new System.Windows.Forms.Label();
            this.Sector_Label_1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Symbol_TextBox_13 = new System.Windows.Forms.TextBox();
            this.Name_TextBox_13 = new System.Windows.Forms.TextBox();
            this.Sector_TextBox_13 = new System.Windows.Forms.TextBox();
            this.Industry_TextBox_13 = new System.Windows.Forms.TextBox();
            this.WebsiteURL_TextBox_13 = new System.Windows.Forms.TextBox();
            this.Description_TextBox_13 = new System.Windows.Forms.TextBox();
            this.CEO_TextBox_13 = new System.Windows.Forms.TextBox();
            this.Phone_TextBox_13 = new System.Windows.Forms.TextBox();
            this.Address_TextBox_13 = new System.Windows.Forms.TextBox();
            this.ZipCode_TextBox_13 = new System.Windows.Forms.TextBox();
            this.City_ComboBox_4 = new System.Windows.Forms.ComboBox();
            this.Country_ComboBox_4 = new System.Windows.Forms.ComboBox();
            this.CreateCompany_Button_1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CreateCompany_Label_1
            // 
            this.CreateCompany_Label_1.AutoSize = true;
            this.CreateCompany_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CreateCompany_Label_1.Location = new System.Drawing.Point(12, 9);
            this.CreateCompany_Label_1.Name = "CreateCompany_Label_1";
            this.CreateCompany_Label_1.Size = new System.Drawing.Size(151, 24);
            this.CreateCompany_Label_1.TabIndex = 0;
            this.CreateCompany_Label_1.Text = "Create Company";
            this.CreateCompany_Label_1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Symbol_Label_2
            // 
            this.Symbol_Label_2.AutoSize = true;
            this.Symbol_Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Symbol_Label_2.Location = new System.Drawing.Point(12, 108);
            this.Symbol_Label_2.Name = "Symbol_Label_2";
            this.Symbol_Label_2.Size = new System.Drawing.Size(73, 24);
            this.Symbol_Label_2.TabIndex = 1;
            this.Symbol_Label_2.Text = "Symbol";
            // 
            // Name_Label_1
            // 
            this.Name_Label_1.AutoSize = true;
            this.Name_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Name_Label_1.Location = new System.Drawing.Point(12, 190);
            this.Name_Label_1.Name = "Name_Label_1";
            this.Name_Label_1.Size = new System.Drawing.Size(61, 24);
            this.Name_Label_1.TabIndex = 2;
            this.Name_Label_1.Text = "Name";
            // 
            // Sector_Label_1
            // 
            this.Sector_Label_1.AutoSize = true;
            this.Sector_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Sector_Label_1.Location = new System.Drawing.Point(12, 269);
            this.Sector_Label_1.Name = "Sector_Label_1";
            this.Sector_Label_1.Size = new System.Drawing.Size(64, 24);
            this.Sector_Label_1.TabIndex = 3;
            this.Sector_Label_1.Text = "Sector";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label5.Location = new System.Drawing.Point(12, 361);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Indusrty";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label6.Location = new System.Drawing.Point(12, 448);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "WebsiteURL";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label7.Location = new System.Drawing.Point(12, 547);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "Description";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label8.Location = new System.Drawing.Point(12, 652);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "CEO";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label9.Location = new System.Drawing.Point(12, 767);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 24);
            this.label9.TabIndex = 8;
            this.label9.Text = "Country";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label10.Location = new System.Drawing.Point(679, 108);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "Phone";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label11.Location = new System.Drawing.Point(679, 190);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(80, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "Address";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label12.Location = new System.Drawing.Point(679, 269);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 24);
            this.label12.TabIndex = 11;
            this.label12.Text = "City";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label13.Location = new System.Drawing.Point(679, 361);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 24);
            this.label13.TabIndex = 12;
            this.label13.Text = "ZipCode";
            // 
            // Symbol_TextBox_13
            // 
            this.Symbol_TextBox_13.Location = new System.Drawing.Point(127, 100);
            this.Symbol_TextBox_13.Name = "Symbol_TextBox_13";
            this.Symbol_TextBox_13.Size = new System.Drawing.Size(100, 20);
            this.Symbol_TextBox_13.TabIndex = 13;
            // 
            // Name_TextBox_13
            // 
            this.Name_TextBox_13.Location = new System.Drawing.Point(127, 183);
            this.Name_TextBox_13.Name = "Name_TextBox_13";
            this.Name_TextBox_13.Size = new System.Drawing.Size(100, 20);
            this.Name_TextBox_13.TabIndex = 14;
            // 
            // Sector_TextBox_13
            // 
            this.Sector_TextBox_13.Location = new System.Drawing.Point(127, 262);
            this.Sector_TextBox_13.Name = "Sector_TextBox_13";
            this.Sector_TextBox_13.Size = new System.Drawing.Size(100, 20);
            this.Sector_TextBox_13.TabIndex = 15;
            // 
            // Industry_TextBox_13
            // 
            this.Industry_TextBox_13.Location = new System.Drawing.Point(127, 354);
            this.Industry_TextBox_13.Name = "Industry_TextBox_13";
            this.Industry_TextBox_13.Size = new System.Drawing.Size(100, 20);
            this.Industry_TextBox_13.TabIndex = 16;
            // 
            // WebsiteURL_TextBox_13
            // 
            this.WebsiteURL_TextBox_13.Location = new System.Drawing.Point(127, 441);
            this.WebsiteURL_TextBox_13.Name = "WebsiteURL_TextBox_13";
            this.WebsiteURL_TextBox_13.Size = new System.Drawing.Size(100, 20);
            this.WebsiteURL_TextBox_13.TabIndex = 17;
            // 
            // Description_TextBox_13
            // 
            this.Description_TextBox_13.Location = new System.Drawing.Point(127, 540);
            this.Description_TextBox_13.Name = "Description_TextBox_13";
            this.Description_TextBox_13.Size = new System.Drawing.Size(100, 20);
            this.Description_TextBox_13.TabIndex = 18;
            // 
            // CEO_TextBox_13
            // 
            this.CEO_TextBox_13.Location = new System.Drawing.Point(127, 645);
            this.CEO_TextBox_13.Name = "CEO_TextBox_13";
            this.CEO_TextBox_13.Size = new System.Drawing.Size(100, 20);
            this.CEO_TextBox_13.TabIndex = 19;
            // 
            // Phone_TextBox_13
            // 
            this.Phone_TextBox_13.Location = new System.Drawing.Point(786, 100);
            this.Phone_TextBox_13.Name = "Phone_TextBox_13";
            this.Phone_TextBox_13.Size = new System.Drawing.Size(100, 20);
            this.Phone_TextBox_13.TabIndex = 20;
            this.Phone_TextBox_13.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // Address_TextBox_13
            // 
            this.Address_TextBox_13.Location = new System.Drawing.Point(786, 183);
            this.Address_TextBox_13.Name = "Address_TextBox_13";
            this.Address_TextBox_13.Size = new System.Drawing.Size(100, 20);
            this.Address_TextBox_13.TabIndex = 21;
            // 
            // ZipCode_TextBox_13
            // 
            this.ZipCode_TextBox_13.Location = new System.Drawing.Point(786, 354);
            this.ZipCode_TextBox_13.Name = "ZipCode_TextBox_13";
            this.ZipCode_TextBox_13.Size = new System.Drawing.Size(100, 20);
            this.ZipCode_TextBox_13.TabIndex = 22;
            // 
            // City_ComboBox_4
            // 
            this.City_ComboBox_4.FormattingEnabled = true;
            this.City_ComboBox_4.Location = new System.Drawing.Point(786, 266);
            this.City_ComboBox_4.Name = "City_ComboBox_4";
            this.City_ComboBox_4.Size = new System.Drawing.Size(121, 21);
            this.City_ComboBox_4.TabIndex = 23;
            // 
            // Country_ComboBox_4
            // 
            this.Country_ComboBox_4.FormattingEnabled = true;
            this.Country_ComboBox_4.Location = new System.Drawing.Point(127, 759);
            this.Country_ComboBox_4.Name = "Country_ComboBox_4";
            this.Country_ComboBox_4.Size = new System.Drawing.Size(121, 21);
            this.Country_ComboBox_4.TabIndex = 24;
            // 
            // CreateCompany_Button_1
            // 
            this.CreateCompany_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CreateCompany_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CreateCompany_Button_1.Location = new System.Drawing.Point(795, 529);
            this.CreateCompany_Button_1.Name = "CreateCompany_Button_1";
            this.CreateCompany_Button_1.Size = new System.Drawing.Size(91, 35);
            this.CreateCompany_Button_1.TabIndex = 25;
            this.CreateCompany_Button_1.Text = "Submit";
            this.CreateCompany_Button_1.UseVisualStyleBackColor = false;
            // 
            // CreateCompany_Form_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 876);
            this.Controls.Add(this.CreateCompany_Button_1);
            this.Controls.Add(this.Country_ComboBox_4);
            this.Controls.Add(this.City_ComboBox_4);
            this.Controls.Add(this.ZipCode_TextBox_13);
            this.Controls.Add(this.Address_TextBox_13);
            this.Controls.Add(this.Phone_TextBox_13);
            this.Controls.Add(this.CEO_TextBox_13);
            this.Controls.Add(this.Description_TextBox_13);
            this.Controls.Add(this.WebsiteURL_TextBox_13);
            this.Controls.Add(this.Industry_TextBox_13);
            this.Controls.Add(this.Sector_TextBox_13);
            this.Controls.Add(this.Name_TextBox_13);
            this.Controls.Add(this.Symbol_TextBox_13);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Sector_Label_1);
            this.Controls.Add(this.Name_Label_1);
            this.Controls.Add(this.Symbol_Label_2);
            this.Controls.Add(this.CreateCompany_Label_1);
            this.Name = "CreateCompany_Form_1";
            this.Text = "Create Company";
            this.Load += new System.EventHandler(this.CreateCompany_Form_1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label CreateCompany_Label_1;
        private System.Windows.Forms.Label Symbol_Label_2;
        private System.Windows.Forms.Label Name_Label_1;
        private System.Windows.Forms.Label Sector_Label_1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox Symbol_TextBox_13;
        private System.Windows.Forms.TextBox Name_TextBox_13;
        private System.Windows.Forms.TextBox Sector_TextBox_13;
        private System.Windows.Forms.TextBox Industry_TextBox_13;
        private System.Windows.Forms.TextBox WebsiteURL_TextBox_13;
        private System.Windows.Forms.TextBox Description_TextBox_13;
        private System.Windows.Forms.TextBox CEO_TextBox_13;
        private System.Windows.Forms.TextBox Phone_TextBox_13;
        private System.Windows.Forms.TextBox Address_TextBox_13;
        private System.Windows.Forms.TextBox ZipCode_TextBox_13;
        private System.Windows.Forms.ComboBox City_ComboBox_4;
        private System.Windows.Forms.ComboBox Country_ComboBox_4;
        private System.Windows.Forms.Button CreateCompany_Button_1;
    }
}