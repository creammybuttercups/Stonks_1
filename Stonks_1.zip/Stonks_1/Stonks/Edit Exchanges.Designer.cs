﻿namespace Stonks
{
    partial class EditExchanges_Form_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EditExchange_Button_1 = new System.Windows.Forms.Button();
            this.LastUpdated_TextBox_7 = new System.Windows.Forms.TextBox();
            this.CreatedDate_TextBox_7 = new System.Windows.Forms.TextBox();
            this.Currency_TextBox_7 = new System.Windows.Forms.TextBox();
            this.Name_TextBox_7 = new System.Windows.Forms.TextBox();
            this.LastUpdated_label_1 = new System.Windows.Forms.Label();
            this.CreatedDate_Label_2 = new System.Windows.Forms.Label();
            this.Currency_Label_2 = new System.Windows.Forms.Label();
            this.Name_Label_4 = new System.Windows.Forms.Label();
            this.EditExchange_Label_2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // EditExchange_Button_1
            // 
            this.EditExchange_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.EditExchange_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.EditExchange_Button_1.Location = new System.Drawing.Point(16, 475);
            this.EditExchange_Button_1.Name = "EditExchange_Button_1";
            this.EditExchange_Button_1.Size = new System.Drawing.Size(91, 35);
            this.EditExchange_Button_1.TabIndex = 77;
            this.EditExchange_Button_1.Text = "Submit";
            this.EditExchange_Button_1.UseVisualStyleBackColor = false;
            // 
            // LastUpdated_TextBox_7
            // 
            this.LastUpdated_TextBox_7.Location = new System.Drawing.Point(148, 361);
            this.LastUpdated_TextBox_7.Name = "LastUpdated_TextBox_7";
            this.LastUpdated_TextBox_7.Size = new System.Drawing.Size(100, 20);
            this.LastUpdated_TextBox_7.TabIndex = 68;
            // 
            // CreatedDate_TextBox_7
            // 
            this.CreatedDate_TextBox_7.Location = new System.Drawing.Point(148, 273);
            this.CreatedDate_TextBox_7.Name = "CreatedDate_TextBox_7";
            this.CreatedDate_TextBox_7.Size = new System.Drawing.Size(100, 20);
            this.CreatedDate_TextBox_7.TabIndex = 67;
            // 
            // Currency_TextBox_7
            // 
            this.Currency_TextBox_7.Location = new System.Drawing.Point(127, 183);
            this.Currency_TextBox_7.Name = "Currency_TextBox_7";
            this.Currency_TextBox_7.Size = new System.Drawing.Size(100, 20);
            this.Currency_TextBox_7.TabIndex = 66;
            // 
            // Name_TextBox_7
            // 
            this.Name_TextBox_7.Location = new System.Drawing.Point(127, 108);
            this.Name_TextBox_7.Name = "Name_TextBox_7";
            this.Name_TextBox_7.Size = new System.Drawing.Size(100, 20);
            this.Name_TextBox_7.TabIndex = 65;
            // 
            // LastUpdated_label_1
            // 
            this.LastUpdated_label_1.AutoSize = true;
            this.LastUpdated_label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.LastUpdated_label_1.Location = new System.Drawing.Point(12, 361);
            this.LastUpdated_label_1.Name = "LastUpdated_label_1";
            this.LastUpdated_label_1.Size = new System.Drawing.Size(119, 24);
            this.LastUpdated_label_1.TabIndex = 56;
            this.LastUpdated_label_1.Text = "Last Updated";
            // 
            // CreatedDate_Label_2
            // 
            this.CreatedDate_Label_2.AutoSize = true;
            this.CreatedDate_Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CreatedDate_Label_2.Location = new System.Drawing.Point(12, 269);
            this.CreatedDate_Label_2.Name = "CreatedDate_Label_2";
            this.CreatedDate_Label_2.Size = new System.Drawing.Size(124, 24);
            this.CreatedDate_Label_2.TabIndex = 55;
            this.CreatedDate_Label_2.Text = " Created Date";
            // 
            // Currency_Label_2
            // 
            this.Currency_Label_2.AutoSize = true;
            this.Currency_Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Currency_Label_2.Location = new System.Drawing.Point(12, 190);
            this.Currency_Label_2.Name = "Currency_Label_2";
            this.Currency_Label_2.Size = new System.Drawing.Size(87, 24);
            this.Currency_Label_2.TabIndex = 54;
            this.Currency_Label_2.Text = "Currency";
            // 
            // Name_Label_4
            // 
            this.Name_Label_4.AutoSize = true;
            this.Name_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Name_Label_4.Location = new System.Drawing.Point(12, 108);
            this.Name_Label_4.Name = "Name_Label_4";
            this.Name_Label_4.Size = new System.Drawing.Size(61, 24);
            this.Name_Label_4.TabIndex = 53;
            this.Name_Label_4.Text = "Name";
            // 
            // EditExchange_Label_2
            // 
            this.EditExchange_Label_2.AutoSize = true;
            this.EditExchange_Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.EditExchange_Label_2.Location = new System.Drawing.Point(12, 9);
            this.EditExchange_Label_2.Name = "EditExchange_Label_2";
            this.EditExchange_Label_2.Size = new System.Drawing.Size(134, 24);
            this.EditExchange_Label_2.TabIndex = 52;
            this.EditExchange_Label_2.Text = "Edit Exchange";
            // 
            // EditExchanges_Form_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 876);
            this.Controls.Add(this.EditExchange_Button_1);
            this.Controls.Add(this.LastUpdated_TextBox_7);
            this.Controls.Add(this.CreatedDate_TextBox_7);
            this.Controls.Add(this.Currency_TextBox_7);
            this.Controls.Add(this.Name_TextBox_7);
            this.Controls.Add(this.LastUpdated_label_1);
            this.Controls.Add(this.CreatedDate_Label_2);
            this.Controls.Add(this.Currency_Label_2);
            this.Controls.Add(this.Name_Label_4);
            this.Controls.Add(this.EditExchange_Label_2);
            this.Name = "EditExchanges_Form_1";
            this.Text = "Edit Exchanges";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button EditExchange_Button_1;
        private System.Windows.Forms.TextBox LastUpdated_TextBox_7;
        private System.Windows.Forms.TextBox CreatedDate_TextBox_7;
        private System.Windows.Forms.TextBox Currency_TextBox_7;
        private System.Windows.Forms.TextBox Name_TextBox_7;
        private System.Windows.Forms.Label LastUpdated_label_1;
        private System.Windows.Forms.Label CreatedDate_Label_2;
        private System.Windows.Forms.Label Currency_Label_2;
        private System.Windows.Forms.Label Name_Label_4;
        private System.Windows.Forms.Label EditExchange_Label_2;
    }
}