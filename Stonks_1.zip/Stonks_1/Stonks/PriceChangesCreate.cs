﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stonks
{
    public partial class PriceChangesCreate_form_1 : Form
    {
        public PriceChangesCreate_form_1()
        {
            InitializeComponent();
        }
    }
}
