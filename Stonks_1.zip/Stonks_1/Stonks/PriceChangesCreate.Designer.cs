﻿namespace Stonks
{
    partial class PriceChangesCreate_form_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PriceChangesCreate_Label_1 = new System.Windows.Forms.Label();
            this.LastUpdated_textBox_21 = new System.Windows.Forms.TextBox();
            this.CreatedDate_textBox_22 = new System.Windows.Forms.TextBox();
            this.Currency_textBox_23 = new System.Windows.Forms.TextBox();
            this.Name_textBox_24 = new System.Windows.Forms.TextBox();
            this.LastUpdated_label_4 = new System.Windows.Forms.Label();
            this.CreatedDate_Label_4 = new System.Windows.Forms.Label();
            this.Currency_Label_4 = new System.Windows.Forms.Label();
            this.Name_Label_7 = new System.Windows.Forms.Label();
            this.Volume_textBox_14 = new System.Windows.Forms.TextBox();
            this.PriceDate_textBox_15 = new System.Windows.Forms.TextBox();
            this.AdjClosePrice_textBox_16 = new System.Windows.Forms.TextBox();
            this.ClosePrice_textBox_17 = new System.Windows.Forms.TextBox();
            this.LowPrice_textBox_18 = new System.Windows.Forms.TextBox();
            this.HighPrice_textBox_19 = new System.Windows.Forms.TextBox();
            this.OpenPrice_textBox_20 = new System.Windows.Forms.TextBox();
            this.PriceDate_Label_4 = new System.Windows.Forms.Label();
            this.Volume_Label_4 = new System.Windows.Forms.Label();
            this.AdjClosePrice_Label_4 = new System.Windows.Forms.Label();
            this.ClosePrice_Label_4 = new System.Windows.Forms.Label();
            this.LowPrice_Label_4 = new System.Windows.Forms.Label();
            this.HighPrice_Label_4 = new System.Windows.Forms.Label();
            this.OpenPrice_label_4 = new System.Windows.Forms.Label();
            this.PriceChanges_Button_2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PriceChangesCreate_Label_1
            // 
            this.PriceChangesCreate_Label_1.AutoSize = true;
            this.PriceChangesCreate_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.PriceChangesCreate_Label_1.Location = new System.Drawing.Point(12, 22);
            this.PriceChangesCreate_Label_1.Name = "PriceChangesCreate_Label_1";
            this.PriceChangesCreate_Label_1.Size = new System.Drawing.Size(226, 26);
            this.PriceChangesCreate_Label_1.TabIndex = 128;
            this.PriceChangesCreate_Label_1.Text = "Price Changes Create";
            // 
            // LastUpdated_textBox_21
            // 
            this.LastUpdated_textBox_21.Location = new System.Drawing.Point(144, 354);
            this.LastUpdated_textBox_21.Name = "LastUpdated_textBox_21";
            this.LastUpdated_textBox_21.Size = new System.Drawing.Size(100, 20);
            this.LastUpdated_textBox_21.TabIndex = 127;
            // 
            // CreatedDate_textBox_22
            // 
            this.CreatedDate_textBox_22.Location = new System.Drawing.Point(144, 280);
            this.CreatedDate_textBox_22.Name = "CreatedDate_textBox_22";
            this.CreatedDate_textBox_22.Size = new System.Drawing.Size(100, 20);
            this.CreatedDate_textBox_22.TabIndex = 126;
            // 
            // Currency_textBox_23
            // 
            this.Currency_textBox_23.Location = new System.Drawing.Point(123, 190);
            this.Currency_textBox_23.Name = "Currency_textBox_23";
            this.Currency_textBox_23.Size = new System.Drawing.Size(100, 20);
            this.Currency_textBox_23.TabIndex = 125;
            // 
            // Name_textBox_24
            // 
            this.Name_textBox_24.Location = new System.Drawing.Point(123, 115);
            this.Name_textBox_24.Name = "Name_textBox_24";
            this.Name_textBox_24.Size = new System.Drawing.Size(100, 20);
            this.Name_textBox_24.TabIndex = 124;
            // 
            // LastUpdated_label_4
            // 
            this.LastUpdated_label_4.AutoSize = true;
            this.LastUpdated_label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.LastUpdated_label_4.Location = new System.Drawing.Point(8, 350);
            this.LastUpdated_label_4.Name = "LastUpdated_label_4";
            this.LastUpdated_label_4.Size = new System.Drawing.Size(119, 24);
            this.LastUpdated_label_4.TabIndex = 123;
            this.LastUpdated_label_4.Text = "Last Updated";
            // 
            // CreatedDate_Label_4
            // 
            this.CreatedDate_Label_4.AutoSize = true;
            this.CreatedDate_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CreatedDate_Label_4.Location = new System.Drawing.Point(8, 276);
            this.CreatedDate_Label_4.Name = "CreatedDate_Label_4";
            this.CreatedDate_Label_4.Size = new System.Drawing.Size(124, 24);
            this.CreatedDate_Label_4.TabIndex = 122;
            this.CreatedDate_Label_4.Text = " Created Date";
            // 
            // Currency_Label_4
            // 
            this.Currency_Label_4.AutoSize = true;
            this.Currency_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Currency_Label_4.Location = new System.Drawing.Point(8, 197);
            this.Currency_Label_4.Name = "Currency_Label_4";
            this.Currency_Label_4.Size = new System.Drawing.Size(87, 24);
            this.Currency_Label_4.TabIndex = 121;
            this.Currency_Label_4.Text = "Currency";
            // 
            // Name_Label_7
            // 
            this.Name_Label_7.AutoSize = true;
            this.Name_Label_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Name_Label_7.Location = new System.Drawing.Point(8, 115);
            this.Name_Label_7.Name = "Name_Label_7";
            this.Name_Label_7.Size = new System.Drawing.Size(61, 24);
            this.Name_Label_7.TabIndex = 120;
            this.Name_Label_7.Text = "Name";
            // 
            // Volume_textBox_14
            // 
            this.Volume_textBox_14.Location = new System.Drawing.Point(458, 414);
            this.Volume_textBox_14.Name = "Volume_textBox_14";
            this.Volume_textBox_14.Size = new System.Drawing.Size(100, 20);
            this.Volume_textBox_14.TabIndex = 119;
            // 
            // PriceDate_textBox_15
            // 
            this.PriceDate_textBox_15.Location = new System.Drawing.Point(777, 113);
            this.PriceDate_textBox_15.Name = "PriceDate_textBox_15";
            this.PriceDate_textBox_15.Size = new System.Drawing.Size(100, 20);
            this.PriceDate_textBox_15.TabIndex = 118;
            // 
            // AdjClosePrice_textBox_16
            // 
            this.AdjClosePrice_textBox_16.Location = new System.Drawing.Point(516, 353);
            this.AdjClosePrice_textBox_16.Name = "AdjClosePrice_textBox_16";
            this.AdjClosePrice_textBox_16.Size = new System.Drawing.Size(100, 20);
            this.AdjClosePrice_textBox_16.TabIndex = 117;
            // 
            // ClosePrice_textBox_17
            // 
            this.ClosePrice_textBox_17.Location = new System.Drawing.Point(460, 276);
            this.ClosePrice_textBox_17.Name = "ClosePrice_textBox_17";
            this.ClosePrice_textBox_17.Size = new System.Drawing.Size(100, 20);
            this.ClosePrice_textBox_17.TabIndex = 116;
            // 
            // LowPrice_textBox_18
            // 
            this.LowPrice_textBox_18.Location = new System.Drawing.Point(458, 190);
            this.LowPrice_textBox_18.Name = "LowPrice_textBox_18";
            this.LowPrice_textBox_18.Size = new System.Drawing.Size(100, 20);
            this.LowPrice_textBox_18.TabIndex = 115;
            // 
            // HighPrice_textBox_19
            // 
            this.HighPrice_textBox_19.Location = new System.Drawing.Point(484, 114);
            this.HighPrice_textBox_19.Name = "HighPrice_textBox_19";
            this.HighPrice_textBox_19.Size = new System.Drawing.Size(100, 20);
            this.HighPrice_textBox_19.TabIndex = 114;
            // 
            // OpenPrice_textBox_20
            // 
            this.OpenPrice_textBox_20.Location = new System.Drawing.Point(139, 419);
            this.OpenPrice_textBox_20.Name = "OpenPrice_textBox_20";
            this.OpenPrice_textBox_20.Size = new System.Drawing.Size(100, 20);
            this.OpenPrice_textBox_20.TabIndex = 113;
            // 
            // PriceDate_Label_4
            // 
            this.PriceDate_Label_4.AutoSize = true;
            this.PriceDate_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.PriceDate_Label_4.Location = new System.Drawing.Point(671, 109);
            this.PriceDate_Label_4.Name = "PriceDate_Label_4";
            this.PriceDate_Label_4.Size = new System.Drawing.Size(96, 24);
            this.PriceDate_Label_4.TabIndex = 112;
            this.PriceDate_Label_4.Text = "Price Date";
            // 
            // Volume_Label_4
            // 
            this.Volume_Label_4.AutoSize = true;
            this.Volume_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Volume_Label_4.Location = new System.Drawing.Point(351, 414);
            this.Volume_Label_4.Name = "Volume_Label_4";
            this.Volume_Label_4.Size = new System.Drawing.Size(76, 24);
            this.Volume_Label_4.TabIndex = 111;
            this.Volume_Label_4.Text = "Volume";
            // 
            // AdjClosePrice_Label_4
            // 
            this.AdjClosePrice_Label_4.AutoSize = true;
            this.AdjClosePrice_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.AdjClosePrice_Label_4.Location = new System.Drawing.Point(351, 349);
            this.AdjClosePrice_Label_4.Name = "AdjClosePrice_Label_4";
            this.AdjClosePrice_Label_4.Size = new System.Drawing.Size(139, 24);
            this.AdjClosePrice_Label_4.TabIndex = 110;
            this.AdjClosePrice_Label_4.Text = "Adj Close Price";
            // 
            // ClosePrice_Label_4
            // 
            this.ClosePrice_Label_4.AutoSize = true;
            this.ClosePrice_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.ClosePrice_Label_4.Location = new System.Drawing.Point(351, 275);
            this.ClosePrice_Label_4.Name = "ClosePrice_Label_4";
            this.ClosePrice_Label_4.Size = new System.Drawing.Size(106, 24);
            this.ClosePrice_Label_4.TabIndex = 109;
            this.ClosePrice_Label_4.Text = "Close Price";
            // 
            // LowPrice_Label_4
            // 
            this.LowPrice_Label_4.AutoSize = true;
            this.LowPrice_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.LowPrice_Label_4.Location = new System.Drawing.Point(351, 186);
            this.LowPrice_Label_4.Name = "LowPrice_Label_4";
            this.LowPrice_Label_4.Size = new System.Drawing.Size(93, 24);
            this.LowPrice_Label_4.TabIndex = 108;
            this.LowPrice_Label_4.Text = "Low Price";
            // 
            // HighPrice_Label_4
            // 
            this.HighPrice_Label_4.AutoSize = true;
            this.HighPrice_Label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.HighPrice_Label_4.Location = new System.Drawing.Point(351, 110);
            this.HighPrice_Label_4.Name = "HighPrice_Label_4";
            this.HighPrice_Label_4.Size = new System.Drawing.Size(98, 24);
            this.HighPrice_Label_4.TabIndex = 107;
            this.HighPrice_Label_4.Text = "High Price";
            // 
            // OpenPrice_label_4
            // 
            this.OpenPrice_label_4.AutoSize = true;
            this.OpenPrice_label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.OpenPrice_label_4.Location = new System.Drawing.Point(2, 419);
            this.OpenPrice_label_4.Name = "OpenPrice_label_4";
            this.OpenPrice_label_4.Size = new System.Drawing.Size(106, 24);
            this.OpenPrice_label_4.TabIndex = 106;
            this.OpenPrice_label_4.Text = "Open Price";
            // 
            // PriceChanges_Button_2
            // 
            this.PriceChanges_Button_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PriceChanges_Button_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.PriceChanges_Button_2.Location = new System.Drawing.Point(777, 212);
            this.PriceChanges_Button_2.Name = "PriceChanges_Button_2";
            this.PriceChanges_Button_2.Size = new System.Drawing.Size(91, 35);
            this.PriceChanges_Button_2.TabIndex = 129;
            this.PriceChanges_Button_2.Text = "Submit";
            this.PriceChanges_Button_2.UseVisualStyleBackColor = false;
            // 
            // PriceChangesCreate_form_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 876);
            this.Controls.Add(this.PriceChanges_Button_2);
            this.Controls.Add(this.PriceChangesCreate_Label_1);
            this.Controls.Add(this.LastUpdated_textBox_21);
            this.Controls.Add(this.CreatedDate_textBox_22);
            this.Controls.Add(this.Currency_textBox_23);
            this.Controls.Add(this.Name_textBox_24);
            this.Controls.Add(this.LastUpdated_label_4);
            this.Controls.Add(this.CreatedDate_Label_4);
            this.Controls.Add(this.Currency_Label_4);
            this.Controls.Add(this.Name_Label_7);
            this.Controls.Add(this.Volume_textBox_14);
            this.Controls.Add(this.PriceDate_textBox_15);
            this.Controls.Add(this.AdjClosePrice_textBox_16);
            this.Controls.Add(this.ClosePrice_textBox_17);
            this.Controls.Add(this.LowPrice_textBox_18);
            this.Controls.Add(this.HighPrice_textBox_19);
            this.Controls.Add(this.OpenPrice_textBox_20);
            this.Controls.Add(this.PriceDate_Label_4);
            this.Controls.Add(this.Volume_Label_4);
            this.Controls.Add(this.AdjClosePrice_Label_4);
            this.Controls.Add(this.ClosePrice_Label_4);
            this.Controls.Add(this.LowPrice_Label_4);
            this.Controls.Add(this.HighPrice_Label_4);
            this.Controls.Add(this.OpenPrice_label_4);
            this.Name = "PriceChangesCreate_form_1";
            this.Text = "Price Changes Create";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PriceChangesCreate_Label_1;
        private System.Windows.Forms.TextBox LastUpdated_textBox_21;
        private System.Windows.Forms.TextBox CreatedDate_textBox_22;
        private System.Windows.Forms.TextBox Currency_textBox_23;
        private System.Windows.Forms.TextBox Name_textBox_24;
        private System.Windows.Forms.Label LastUpdated_label_4;
        private System.Windows.Forms.Label CreatedDate_Label_4;
        private System.Windows.Forms.Label Currency_Label_4;
        private System.Windows.Forms.Label Name_Label_7;
        private System.Windows.Forms.TextBox Volume_textBox_14;
        private System.Windows.Forms.TextBox PriceDate_textBox_15;
        private System.Windows.Forms.TextBox AdjClosePrice_textBox_16;
        private System.Windows.Forms.TextBox ClosePrice_textBox_17;
        private System.Windows.Forms.TextBox LowPrice_textBox_18;
        private System.Windows.Forms.TextBox HighPrice_textBox_19;
        private System.Windows.Forms.TextBox OpenPrice_textBox_20;
        private System.Windows.Forms.Label PriceDate_Label_4;
        private System.Windows.Forms.Label Volume_Label_4;
        private System.Windows.Forms.Label AdjClosePrice_Label_4;
        private System.Windows.Forms.Label ClosePrice_Label_4;
        private System.Windows.Forms.Label LowPrice_Label_4;
        private System.Windows.Forms.Label HighPrice_Label_4;
        private System.Windows.Forms.Label OpenPrice_label_4;
        private System.Windows.Forms.Button PriceChanges_Button_2;
    }
}