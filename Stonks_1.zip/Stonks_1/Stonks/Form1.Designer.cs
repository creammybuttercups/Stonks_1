﻿namespace Stonks
{
    partial class HomeScreen_Form_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Companies_Label_1 = new System.Windows.Forms.Label();
            this.CompaniesCreate_Button_1 = new System.Windows.Forms.Button();
            this.CompaniesEdit_Button_1 = new System.Windows.Forms.Button();
            this.CompaniesDelete_Button_1 = new System.Windows.Forms.Button();
            this.CompaniesDetails_Button_1 = new System.Windows.Forms.Button();
            this.Companies_DataGridView_2 = new System.Windows.Forms.DataGridView();
            this.Exchange_DataGridView_2 = new System.Windows.Forms.DataGridView();
            this.Exchange_label_1 = new System.Windows.Forms.Label();
            this.Companies_vScrollBar_1 = new System.Windows.Forms.VScrollBar();
            this.Exchange_vScrollBar_1 = new System.Windows.Forms.VScrollBar();
            this.ExchangeCreate_Button_2 = new System.Windows.Forms.Button();
            this.ExchangeDelete_Button_2 = new System.Windows.Forms.Button();
            this.ExchangeEdit_Button_2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Companies_DataGridView_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Exchange_DataGridView_2)).BeginInit();
            this.SuspendLayout();
            // 
            // Companies_Label_1
            // 
            this.Companies_Label_1.AutoSize = true;
            this.Companies_Label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Companies_Label_1.Location = new System.Drawing.Point(12, 161);
            this.Companies_Label_1.Name = "Companies_Label_1";
            this.Companies_Label_1.Size = new System.Drawing.Size(106, 24);
            this.Companies_Label_1.TabIndex = 0;
            this.Companies_Label_1.Text = "Companies";
            // 
            // CompaniesCreate_Button_1
            // 
            this.CompaniesCreate_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CompaniesCreate_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CompaniesCreate_Button_1.Location = new System.Drawing.Point(16, 25);
            this.CompaniesCreate_Button_1.Name = "CompaniesCreate_Button_1";
            this.CompaniesCreate_Button_1.Size = new System.Drawing.Size(91, 34);
            this.CompaniesCreate_Button_1.TabIndex = 1;
            this.CompaniesCreate_Button_1.Text = "Create";
            this.CompaniesCreate_Button_1.UseVisualStyleBackColor = false;
            // 
            // CompaniesEdit_Button_1
            // 
            this.CompaniesEdit_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CompaniesEdit_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CompaniesEdit_Button_1.Location = new System.Drawing.Point(825, 25);
            this.CompaniesEdit_Button_1.Name = "CompaniesEdit_Button_1";
            this.CompaniesEdit_Button_1.Size = new System.Drawing.Size(91, 34);
            this.CompaniesEdit_Button_1.TabIndex = 2;
            this.CompaniesEdit_Button_1.Text = "Edit";
            this.CompaniesEdit_Button_1.UseVisualStyleBackColor = false;
            // 
            // CompaniesDelete_Button_1
            // 
            this.CompaniesDelete_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CompaniesDelete_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CompaniesDelete_Button_1.Location = new System.Drawing.Point(955, 25);
            this.CompaniesDelete_Button_1.Name = "CompaniesDelete_Button_1";
            this.CompaniesDelete_Button_1.Size = new System.Drawing.Size(91, 34);
            this.CompaniesDelete_Button_1.TabIndex = 3;
            this.CompaniesDelete_Button_1.Text = "Delete";
            this.CompaniesDelete_Button_1.UseVisualStyleBackColor = false;
            // 
            // CompaniesDetails_Button_1
            // 
            this.CompaniesDetails_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CompaniesDetails_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.CompaniesDetails_Button_1.Location = new System.Drawing.Point(1092, 25);
            this.CompaniesDetails_Button_1.Name = "CompaniesDetails_Button_1";
            this.CompaniesDetails_Button_1.Size = new System.Drawing.Size(91, 34);
            this.CompaniesDetails_Button_1.TabIndex = 4;
            this.CompaniesDetails_Button_1.Text = "Details";
            this.CompaniesDetails_Button_1.UseVisualStyleBackColor = false;
            // 
            // Companies_DataGridView_2
            // 
            this.Companies_DataGridView_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Companies_DataGridView_2.Location = new System.Drawing.Point(16, 202);
            this.Companies_DataGridView_2.Name = "Companies_DataGridView_2";
            this.Companies_DataGridView_2.Size = new System.Drawing.Size(1184, 150);
            this.Companies_DataGridView_2.TabIndex = 5;
            // 
            // Exchange_DataGridView_2
            // 
            this.Exchange_DataGridView_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Exchange_DataGridView_2.Location = new System.Drawing.Point(16, 550);
            this.Exchange_DataGridView_2.Name = "Exchange_DataGridView_2";
            this.Exchange_DataGridView_2.Size = new System.Drawing.Size(1184, 150);
            this.Exchange_DataGridView_2.TabIndex = 7;
            // 
            // Exchange_label_1
            // 
            this.Exchange_label_1.AutoSize = true;
            this.Exchange_label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Exchange_label_1.Location = new System.Drawing.Point(12, 511);
            this.Exchange_label_1.Name = "Exchange_label_1";
            this.Exchange_label_1.Size = new System.Drawing.Size(97, 24);
            this.Exchange_label_1.TabIndex = 8;
            this.Exchange_label_1.Text = "Exchange";
            // 
            // Companies_vScrollBar_1
            // 
            this.Companies_vScrollBar_1.Location = new System.Drawing.Point(1180, 202);
            this.Companies_vScrollBar_1.Name = "Companies_vScrollBar_1";
            this.Companies_vScrollBar_1.Size = new System.Drawing.Size(20, 150);
            this.Companies_vScrollBar_1.TabIndex = 6;
            // 
            // Exchange_vScrollBar_1
            // 
            this.Exchange_vScrollBar_1.Location = new System.Drawing.Point(1180, 550);
            this.Exchange_vScrollBar_1.Name = "Exchange_vScrollBar_1";
            this.Exchange_vScrollBar_1.Size = new System.Drawing.Size(20, 150);
            this.Exchange_vScrollBar_1.TabIndex = 9;
            // 
            // ExchangeCreate_Button_2
            // 
            this.ExchangeCreate_Button_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ExchangeCreate_Button_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.ExchangeCreate_Button_2.Location = new System.Drawing.Point(825, 484);
            this.ExchangeCreate_Button_2.Name = "ExchangeCreate_Button_2";
            this.ExchangeCreate_Button_2.Size = new System.Drawing.Size(91, 34);
            this.ExchangeCreate_Button_2.TabIndex = 12;
            this.ExchangeCreate_Button_2.Text = "Create";
            this.ExchangeCreate_Button_2.UseVisualStyleBackColor = false;
            // 
            // ExchangeDelete_Button_2
            // 
            this.ExchangeDelete_Button_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ExchangeDelete_Button_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.ExchangeDelete_Button_2.Location = new System.Drawing.Point(955, 484);
            this.ExchangeDelete_Button_2.Name = "ExchangeDelete_Button_2";
            this.ExchangeDelete_Button_2.Size = new System.Drawing.Size(91, 34);
            this.ExchangeDelete_Button_2.TabIndex = 11;
            this.ExchangeDelete_Button_2.Text = "Delete";
            this.ExchangeDelete_Button_2.UseVisualStyleBackColor = false;
            // 
            // ExchangeEdit_Button_2
            // 
            this.ExchangeEdit_Button_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ExchangeEdit_Button_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.ExchangeEdit_Button_2.Location = new System.Drawing.Point(1092, 484);
            this.ExchangeEdit_Button_2.Name = "ExchangeEdit_Button_2";
            this.ExchangeEdit_Button_2.Size = new System.Drawing.Size(91, 34);
            this.ExchangeEdit_Button_2.TabIndex = 10;
            this.ExchangeEdit_Button_2.Text = "Edit";
            this.ExchangeEdit_Button_2.UseVisualStyleBackColor = false;
            // 
            // HomeScreen_Form_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 876);
            this.Controls.Add(this.ExchangeCreate_Button_2);
            this.Controls.Add(this.ExchangeDelete_Button_2);
            this.Controls.Add(this.ExchangeEdit_Button_2);
            this.Controls.Add(this.Exchange_vScrollBar_1);
            this.Controls.Add(this.Exchange_label_1);
            this.Controls.Add(this.Exchange_DataGridView_2);
            this.Controls.Add(this.Companies_vScrollBar_1);
            this.Controls.Add(this.Companies_DataGridView_2);
            this.Controls.Add(this.CompaniesDetails_Button_1);
            this.Controls.Add(this.CompaniesDelete_Button_1);
            this.Controls.Add(this.CompaniesEdit_Button_1);
            this.Controls.Add(this.CompaniesCreate_Button_1);
            this.Controls.Add(this.Companies_Label_1);
            this.Name = "HomeScreen_Form_1";
            this.Text = "Homes Screen";
            ((System.ComponentModel.ISupportInitialize)(this.Companies_DataGridView_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Exchange_DataGridView_2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Companies_Label_1;
        private System.Windows.Forms.Button CompaniesCreate_Button_1;
        private System.Windows.Forms.Button CompaniesEdit_Button_1;
        private System.Windows.Forms.Button CompaniesDelete_Button_1;
        private System.Windows.Forms.Button CompaniesDetails_Button_1;
        private System.Windows.Forms.DataGridView Companies_DataGridView_2;
        private System.Windows.Forms.DataGridView Exchange_DataGridView_2;
        private System.Windows.Forms.Label Exchange_label_1;
        private System.Windows.Forms.VScrollBar Companies_vScrollBar_1;
        private System.Windows.Forms.VScrollBar Exchange_vScrollBar_1;
        private System.Windows.Forms.Button ExchangeCreate_Button_2;
        private System.Windows.Forms.Button ExchangeDelete_Button_2;
        private System.Windows.Forms.Button ExchangeEdit_Button_2;
    }
}

