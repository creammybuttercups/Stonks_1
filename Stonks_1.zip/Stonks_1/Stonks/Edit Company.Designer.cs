﻿namespace Stonks
{
    partial class Edit_Company
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EditCompany_Button_1 = new System.Windows.Forms.Button();
            this.Country_ComboBox_2 = new System.Windows.Forms.ComboBox();
            this.City_ComboBox_1 = new System.Windows.Forms.ComboBox();
            this.ZipCode_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Address_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Phone_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Ceo_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Description_TextBox_1 = new System.Windows.Forms.TextBox();
            this.WebsiteURL_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Industry_TextBox_1 = new System.Windows.Forms.TextBox();
            this.Sector__TextBox_1 = new System.Windows.Forms.TextBox();
            this.Name_TextBox_12 = new System.Windows.Forms.TextBox();
            this.Symbol_TextBox_1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Sector_Label_2 = new System.Windows.Forms.Label();
            this.Name_Label_2 = new System.Windows.Forms.Label();
            this.Symbol_Label_3 = new System.Windows.Forms.Label();
            this.EditCompany_Label_2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // EditCompany_Button_1
            // 
            this.EditCompany_Button_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.EditCompany_Button_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.EditCompany_Button_1.Location = new System.Drawing.Point(795, 529);
            this.EditCompany_Button_1.Name = "EditCompany_Button_1";
            this.EditCompany_Button_1.Size = new System.Drawing.Size(91, 35);
            this.EditCompany_Button_1.TabIndex = 51;
            this.EditCompany_Button_1.Text = "Submit";
            this.EditCompany_Button_1.UseVisualStyleBackColor = false;
            // 
            // Country_ComboBox_2
            // 
            this.Country_ComboBox_2.FormattingEnabled = true;
            this.Country_ComboBox_2.Location = new System.Drawing.Point(127, 759);
            this.Country_ComboBox_2.Name = "Country_ComboBox_2";
            this.Country_ComboBox_2.Size = new System.Drawing.Size(121, 21);
            this.Country_ComboBox_2.TabIndex = 50;
            // 
            // City_ComboBox_1
            // 
            this.City_ComboBox_1.FormattingEnabled = true;
            this.City_ComboBox_1.Location = new System.Drawing.Point(786, 266);
            this.City_ComboBox_1.Name = "City_ComboBox_1";
            this.City_ComboBox_1.Size = new System.Drawing.Size(121, 21);
            this.City_ComboBox_1.TabIndex = 49;
            // 
            // ZipCode_TextBox_1
            // 
            this.ZipCode_TextBox_1.Location = new System.Drawing.Point(786, 354);
            this.ZipCode_TextBox_1.Name = "ZipCode_TextBox_1";
            this.ZipCode_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.ZipCode_TextBox_1.TabIndex = 48;
            // 
            // Address_TextBox_1
            // 
            this.Address_TextBox_1.Location = new System.Drawing.Point(786, 183);
            this.Address_TextBox_1.Name = "Address_TextBox_1";
            this.Address_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Address_TextBox_1.TabIndex = 47;
            // 
            // Phone_TextBox_1
            // 
            this.Phone_TextBox_1.Location = new System.Drawing.Point(786, 100);
            this.Phone_TextBox_1.Name = "Phone_TextBox_1";
            this.Phone_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Phone_TextBox_1.TabIndex = 46;
            // 
            // Ceo_TextBox_1
            // 
            this.Ceo_TextBox_1.Location = new System.Drawing.Point(127, 645);
            this.Ceo_TextBox_1.Name = "Ceo_TextBox_1";
            this.Ceo_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Ceo_TextBox_1.TabIndex = 45;
            // 
            // Description_TextBox_1
            // 
            this.Description_TextBox_1.Location = new System.Drawing.Point(127, 540);
            this.Description_TextBox_1.Name = "Description_TextBox_1";
            this.Description_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Description_TextBox_1.TabIndex = 44;
            // 
            // WebsiteURL_TextBox_1
            // 
            this.WebsiteURL_TextBox_1.Location = new System.Drawing.Point(127, 441);
            this.WebsiteURL_TextBox_1.Name = "WebsiteURL_TextBox_1";
            this.WebsiteURL_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.WebsiteURL_TextBox_1.TabIndex = 43;
            // 
            // Industry_TextBox_1
            // 
            this.Industry_TextBox_1.Location = new System.Drawing.Point(127, 354);
            this.Industry_TextBox_1.Name = "Industry_TextBox_1";
            this.Industry_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Industry_TextBox_1.TabIndex = 42;
            // 
            // Sector__TextBox_1
            // 
            this.Sector__TextBox_1.Location = new System.Drawing.Point(127, 262);
            this.Sector__TextBox_1.Name = "Sector__TextBox_1";
            this.Sector__TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Sector__TextBox_1.TabIndex = 41;
            // 
            // Name_TextBox_12
            // 
            this.Name_TextBox_12.Location = new System.Drawing.Point(127, 183);
            this.Name_TextBox_12.Name = "Name_TextBox_12";
            this.Name_TextBox_12.Size = new System.Drawing.Size(100, 20);
            this.Name_TextBox_12.TabIndex = 40;
            // 
            // Symbol_TextBox_1
            // 
            this.Symbol_TextBox_1.Location = new System.Drawing.Point(127, 100);
            this.Symbol_TextBox_1.Name = "Symbol_TextBox_1";
            this.Symbol_TextBox_1.Size = new System.Drawing.Size(100, 20);
            this.Symbol_TextBox_1.TabIndex = 39;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label13.Location = new System.Drawing.Point(679, 361);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 24);
            this.label13.TabIndex = 38;
            this.label13.Text = "ZipCode";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label12.Location = new System.Drawing.Point(679, 269);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 24);
            this.label12.TabIndex = 37;
            this.label12.Text = "City";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label11.Location = new System.Drawing.Point(679, 190);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(80, 24);
            this.label11.TabIndex = 36;
            this.label11.Text = "Address";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label10.Location = new System.Drawing.Point(679, 108);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 24);
            this.label10.TabIndex = 35;
            this.label10.Text = "Phone";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label9.Location = new System.Drawing.Point(12, 767);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 24);
            this.label9.TabIndex = 34;
            this.label9.Text = "Country";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label8.Location = new System.Drawing.Point(12, 652);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 24);
            this.label8.TabIndex = 33;
            this.label8.Text = "CEO";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label7.Location = new System.Drawing.Point(12, 547);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 24);
            this.label7.TabIndex = 32;
            this.label7.Text = "Description";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label6.Location = new System.Drawing.Point(12, 448);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 24);
            this.label6.TabIndex = 31;
            this.label6.Text = "WebsiteURL";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label5.Location = new System.Drawing.Point(12, 361);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 24);
            this.label5.TabIndex = 30;
            this.label5.Text = "Indusrty";
            // 
            // Sector_Label_2
            // 
            this.Sector_Label_2.AutoSize = true;
            this.Sector_Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Sector_Label_2.Location = new System.Drawing.Point(12, 269);
            this.Sector_Label_2.Name = "Sector_Label_2";
            this.Sector_Label_2.Size = new System.Drawing.Size(64, 24);
            this.Sector_Label_2.TabIndex = 29;
            this.Sector_Label_2.Text = "Sector";
            // 
            // Name_Label_2
            // 
            this.Name_Label_2.AutoSize = true;
            this.Name_Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Name_Label_2.Location = new System.Drawing.Point(12, 190);
            this.Name_Label_2.Name = "Name_Label_2";
            this.Name_Label_2.Size = new System.Drawing.Size(61, 24);
            this.Name_Label_2.TabIndex = 28;
            this.Name_Label_2.Text = "Name";
            // 
            // Symbol_Label_3
            // 
            this.Symbol_Label_3.AutoSize = true;
            this.Symbol_Label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Symbol_Label_3.Location = new System.Drawing.Point(12, 108);
            this.Symbol_Label_3.Name = "Symbol_Label_3";
            this.Symbol_Label_3.Size = new System.Drawing.Size(73, 24);
            this.Symbol_Label_3.TabIndex = 27;
            this.Symbol_Label_3.Text = "Symbol";
            // 
            // EditCompany_Label_2
            // 
            this.EditCompany_Label_2.AutoSize = true;
            this.EditCompany_Label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.EditCompany_Label_2.Location = new System.Drawing.Point(12, 9);
            this.EditCompany_Label_2.Name = "EditCompany_Label_2";
            this.EditCompany_Label_2.Size = new System.Drawing.Size(128, 24);
            this.EditCompany_Label_2.TabIndex = 26;
            this.EditCompany_Label_2.Text = "Edit Company";
            // 
            // Edit_Company
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 876);
            this.Controls.Add(this.EditCompany_Button_1);
            this.Controls.Add(this.Country_ComboBox_2);
            this.Controls.Add(this.City_ComboBox_1);
            this.Controls.Add(this.ZipCode_TextBox_1);
            this.Controls.Add(this.Address_TextBox_1);
            this.Controls.Add(this.Phone_TextBox_1);
            this.Controls.Add(this.Ceo_TextBox_1);
            this.Controls.Add(this.Description_TextBox_1);
            this.Controls.Add(this.WebsiteURL_TextBox_1);
            this.Controls.Add(this.Industry_TextBox_1);
            this.Controls.Add(this.Sector__TextBox_1);
            this.Controls.Add(this.Name_TextBox_12);
            this.Controls.Add(this.Symbol_TextBox_1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Sector_Label_2);
            this.Controls.Add(this.Name_Label_2);
            this.Controls.Add(this.Symbol_Label_3);
            this.Controls.Add(this.EditCompany_Label_2);
            this.Name = "Edit_Company";
            this.Text = "Edit Company";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button EditCompany_Button_1;
        private System.Windows.Forms.ComboBox Country_ComboBox_2;
        private System.Windows.Forms.ComboBox City_ComboBox_1;
        private System.Windows.Forms.TextBox ZipCode_TextBox_1;
        private System.Windows.Forms.TextBox Address_TextBox_1;
        private System.Windows.Forms.TextBox Phone_TextBox_1;
        private System.Windows.Forms.TextBox Ceo_TextBox_1;
        private System.Windows.Forms.TextBox Description_TextBox_1;
        private System.Windows.Forms.TextBox WebsiteURL_TextBox_1;
        private System.Windows.Forms.TextBox Industry_TextBox_1;
        private System.Windows.Forms.TextBox Sector__TextBox_1;
        private System.Windows.Forms.TextBox Name_TextBox_12;
        private System.Windows.Forms.TextBox Symbol_TextBox_1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Sector_Label_2;
        private System.Windows.Forms.Label Name_Label_2;
        private System.Windows.Forms.Label Symbol_Label_3;
        private System.Windows.Forms.Label EditCompany_Label_2;
    }
}